<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
    // Страницы
Route::get('/', ['as' => 'index', 'uses' => 'MainController@index']);
Route::get('/catalog', ['as' => 'catalog', 'uses' => 'MainController@catalog']);
Route::get('/category/{id}', ['as' => 'category', 'uses' => 'MainController@category']);
Route::get('/faq', ['as' => 'faq', 'uses' => 'MainController@faq']);
Route::get('/garant', ['as' => 'garant', 'uses' => 'MainController@garant']);
Route::get('/news', ['as' => 'news', 'uses' => 'MainController@news']);
Route::get('/reviews', ['as' => 'reviews', 'uses' => 'MainController@reviews']);
Route::get('/services', ['as' => 'services', 'uses' => 'MainController@services']);

Route::get('/ref', 'MainController@ref');
Route::post('/result', 'BuyController@result');
    // Авторизация
Route::group(['prefix' => '/auth'], function () {
    Route::get('/vkontakte', ['as' => 'provider.login', 'uses' => 'AuthController@login']);
    Route::get('/callback/vkontakte', 'AuthController@callback');
});


Route::group(['middleware' => 'auth'], function () {
    Route::get('/logout', ['as' => 'logout', 'uses' => 'AuthController@logout']);
    Route::get('/profile', ['as' => 'profile', 'uses' => 'MainController@profile']);

    // Оплата
    Route::get('/pay', ['as' => 'pay', 'uses' => 'BuyController@pay']);
    Route::get('/success', 'BuyController@success');
    Route::get('/fail', 'BuyController@fail');


    Route::get('/product/{id}', 'MainController@product');
    Route::get('/product/{id}/addToBasket', 'MainController@addToBasket');
    Route::get('/product/{id}/removeFromBasket', 'MainController@removeFromBasket');
    Route::get('/product/{id}/buy', 'BuyController@buyProduct');
    Route::get('/buyFromBasket', 'BuyController@buyFromBasket');
    Route::get('/review/post', 'MainController@postReview');
	  Route::get('/promocode/activate', 'MainController@promoActivate');
});


Route::group(['prefix' => '/admin', 'middleware' => 'auth', 'middleware' => 'access:admin'], function () {
    Route::get('/', ['as' => 'admin.index', 'uses' => 'AdminController@index']);
    Route::get('/products', ['as' => 'admin.products', 'uses' => 'AdminController@products']);
    Route::get('/settings', ['as' => 'admin.settings', 'uses' => 'AdminController@settings']);
    Route::get('/support', ['as' => 'admin.support', 'uses' => 'AdminController@index']);
    Route::get('/reviews', ['as' => 'admin.reviews', 'uses' => 'AdminController@reviews']);
    Route::get('/categories', ['as' => 'admin.categories', 'uses' => 'AdminController@categories']);
    Route::get('/users', ['as' => 'admin.users', 'uses' => 'AdminController@users']);
    Route::get('/promo', ['as' => 'admin.promo', 'uses' => 'AdminController@promo']);
    Route::get('/news', ['as' => 'admin.news', 'uses' => 'AdminController@news']);

    Route::get('/category/{id}', ['as' => 'admin.category', 'uses' => 'AdminController@category']);
  	Route::get('/user/{id}', ['as' => 'admin.user', 'uses' => 'AdminController@user']);
    Route::get('/product/status/{product}/{status}', 'AdminController@productStatus');
    Route::get('/product/{id}', ['as' => 'admin.product', 'uses' => 'AdminController@product']);
    Route::get('/promo/delete/{id}', 'AdminController@promoDelete');
    Route::get('/category/status/{category}/{status}', 'AdminController@categoryStatus');
    Route::get('/review/status/{review}/{status}', 'AdminController@reviewStatus');
    Route::get('/news/status/{news}/{status}', 'AdminController@newsStatus');

    Route::post('/user/save', 'AdminController@userSave');
    Route::post('/usersAjax', 'AdminController@usersAjax');
    Route::post('/news/create', 'AdminController@newsCreate');
    Route::post('/news/save', 'AdminController@newsSave');
    Route::post('/promo/create', 'AdminController@promoCreate');
    Route::post('/promo/save', 'AdminController@promoSave');
    Route::post('/product/create', 'AdminController@productCreate');
    Route::post('/product/save', 'AdminController@productSave');
    Route::post('/category/create', 'AdminController@categoryCreate');
    Route::post('/category/save', 'AdminController@categorySave');
  	Route::post('/setting/save', 'AdminController@settingsSave');
});
