<?php $__env->startSection('content'); ?>
    <div class="header-title">
       <div class="wrapper">
            <span>Наши новости</span>
       </div>
    </div>
    <section class="news">
        <div class="news-items">
          <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="item">
              <div class="wrapper flex flex-between">
                  <div class="new-image">
                      <div class="img" style="background: url(<?php echo e($item->image); ?>) no-repeat center center;"></div>
                  </div>
                  <div class="info">
                      <div class="heading flex flex-between">
                          <h4><?php echo e($item->title); ?></h4>
                          <div class="date"><?php echo e(\Carbon\Carbon::parse($item->created_at)->timezone('UTC')->diffForHumans()); ?></div>
                      </div>
                      <div class="product-description">
                        <textarea disabled style="height: 263px; resize: none;"><?php echo e($item->description); ?></textarea>
                      </div>
                  </div>
              </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/a0330028/domains/webgamestore.ru/public_html/resources/views/pages/news.blade.php ENDPATH**/ ?>