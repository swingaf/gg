<?php $__env->startSection('content'); ?>
<script src="/dash/js/dtables.js" type="text/javascript"></script>
<div class="kt-subheader kt-grid__item" id="kt_subheader">
	<div class="kt-subheader__main">
		<h3 class="kt-subheader__title">Отзывы</h3>
	</div>
</div>

<div class="kt-content kt-grid__item kt-grid__item--fluid" id="kt_content">
	<div class="kt-portlet kt-portlet--mobile">
		<div class="kt-portlet__head kt-portlet__head--lg">
			<div class="kt-portlet__head-label">
				<span class="kt-portlet__head-icon">
					<i class="kt-font-brand flaticon2-menu-2"></i>
				</span>
				<h3 class="kt-portlet__head-title">
					Список отзывов
				</h3>
			</div>
		</div>
		<div class="kt-portlet__body">

			<!--begin: Datatable -->
			<table class="table table-striped- table-bordered table-hover table-checkable" id="dtable">
				<thead>
					<tr>
						<th>ID</th>
						<th>Пользователь</th>
						<th>Товар</th>
						<th>Текст</th>
						<th>Информация</th>
						<th>Дата</th>
						<th>Действия</th>
					</tr>
				</thead>
				<tbody>
				<?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($review->id); ?></td>
					<td><a href="/admin/product/<?php echo e($review->reviewOwner->id); ?>"><?php echo e($review->reviewOwner->username); ?></a></td>
					<td><a href="/admin/product/<?php echo e($review->reviewProduct->id); ?>"><?php echo e($review->reviewProduct->title); ?></td>
					<td><?php echo e($review->text); ?></td>
					<td>
						<?php if($review->star == 0): ?> <span class="kt-badge kt-badge--danger kt-badge--inline kt-badge--pill">Отрицательный</span> <?php elseif($review->star == 1): ?> <span class="kt-badge kt-badge--success kt-badge--inline kt-badge--pill">Положительный</span> <?php endif; ?>
						<?php if($review->status == 0): ?> <span class="kt-badge kt-badge--warning kt-badge--inline kt-badge--pill">На модерации</span> <?php elseif($review->status == 1): ?> <span class="kt-badge kt-badge--success kt-badge--inline kt-badge--pill">Одобрен</span> <?php elseif($review->status == 2): ?> <span class="kt-badge kt-badge--danger kt-badge--inline kt-badge--pill">Отклонен</span> <?php endif; ?>
					</td>
					<td><?php echo e($review->created_at->format('d.m.y h:m')); ?></td>
					<td> <?php if($review->status == 0): ?> <a href="/admin/review/status/<?php echo e($review->id); ?>/1" class="btn btn-sm btn-clean btn-icon btn-icon-md" title="Одобрить отзыв"><i class="la la-check"></i></a> <a href="/admin/review/status/<?php echo e($review->id); ?>/2" class="btn btn-sm btn-clean btn-icon btn-icon-md" title="Отклонить отзыв"><i class="la la-close"></i></a>
							 <?php elseif($review->status == 1): ?> <a href="/admin/review/status/<?php echo e($review->id); ?>/2" class="btn btn-sm btn-clean btn-icon btn-icon-md" title="Скрывать отзыв"><i class="la la-eye-slash"></i></a>
							 <?php elseif($review->status == 2): ?> <a href="/admin/review/status/<?php echo e($review->id); ?>/1" class="btn btn-sm btn-clean btn-icon btn-icon-md" title="Показывать отзыв"><i class="la la-eye"></i></a> <?php endif; ?></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>

			<!--end: Datatable -->
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/a0330028/domains/webgamestore.ru/public_html/resources/views/admin/reviews.blade.php ENDPATH**/ ?>