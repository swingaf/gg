<?php $__env->startSection('content'); ?>
<script src="/dash/js/dtables.js" type="text/javascript"></script>
<div class="kt-subheader kt-grid__item" id="kt_subheader">
	<div class="kt-subheader__main">
		<h3 class="kt-subheader__title">Категории</h3>
	</div>
</div>

<div class="kt-content kt-grid__item kt-grid__item--fluid" id="kt_content">
	<div class="kt-portlet kt-portlet--mobile">
		<div class="kt-portlet__head kt-portlet__head--lg">
			<div class="kt-portlet__head-label">
				<span class="kt-portlet__head-icon">
					<i class="kt-font-brand flaticon2-menu-2"></i>
				</span>
				<h3 class="kt-portlet__head-title">
					Список категорий
				</h3>
			</div>
			<div class="kt-portlet__head-toolbar">
				<div class="kt-portlet__head-wrapper">
					<div class="kt-portlet__head-actions">
						<a data-toggle="modal" href="#new" class="btn btn-success btn-elevate btn-icon-sm">
							<i class="la la-plus"></i>
							Создать
						</a>
					</div>
				</div>
			</div>
		</div>
		<div class="kt-portlet__body">

			<!--begin: Datatable -->
			<table class="table table-striped- table-bordered table-hover table-checkable" id="dtable">
				<thead>
					<tr>
						<th>ID</th>
						<th>Название</th>
						<th>Активна?</th>
						<th>Действия</th>
					</tr>
				</thead>
				<tbody>
				<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($category->id); ?></td>
					<td><?php echo e($category->name); ?></td>
					<td>
						<?php if($category->status == 1): ?> <span class="kt-badge kt-badge--success kt-badge--inline kt-badge--pill">Да</span> <?php else: ?> <span class="kt-badge kt-badge--danger kt-badge--inline kt-badge--pill">Нет</span> <?php endif; ?>
					</td>
					<td><a href="/admin/category/<?php echo e($category->id); ?>" class="btn btn-sm btn-clean btn-icon btn-icon-md" title="Редактировать"><i class="la la-edit"></i></a> <?php if($category->status == 1): ?> <a href="/admin/category/status/<?php echo e($category->id); ?>/0" class="btn btn-sm btn-clean btn-icon btn-icon-md" title="Скрывать категорию"><i class="la la-eye-slash"></i></a> <?php elseif($category->status == 0): ?> <a href="/admin/category/status/<?php echo e($category->id); ?>/1" class="btn btn-sm btn-clean btn-icon btn-icon-md" title="Показывать товар"><i class="la la-eye"></i></a> <?php endif; ?></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>

			<!--end: Datatable -->
		</div>
	</div>
</div>
<div class="modal fade" id="new" tabindex="-1" role="dialog" aria-labelledby="newLabel" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Новая категория</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"></button>
            </div>
            <form class="kt-form-new" method="post" action="/admin/category/create">
				<div class="modal-body">
					<div class="form-group">
						<label for="name">Название:</label>
						<input type="text" class="form-control" placeholder="Название" name="name">
					</div>
					<div class="form-group">
						<label for="name">Активна?</label>
						<select class="form-control" name="status">
							<option value="1">Да</option>
							<option value="0">Нет</option>
						</select>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-dismiss="modal">Закрыть</button>
					<button type="submit" class="btn btn-primary">Добавить</button>
				</div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/a0330028/domains/webgamestore.ru/public_html/resources/views/admin/categories.blade.php ENDPATH**/ ?>