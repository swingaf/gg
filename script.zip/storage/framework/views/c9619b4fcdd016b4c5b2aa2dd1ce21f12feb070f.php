<?php $__env->startSection('content'); ?>
    <div class="header-title">
       <div class="wrapper">
            <span>Отзывы наших клиентов</span>
       </div>
    </div>
    <section class="reviews">
        <div class="reviews-items">
            <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="review">
               <div class="wrapper">
                    <div class="top flex flex-between flex-align-center flex-wrap">
                        <div class="profile flex flex-start flex-align-center">
                            <div class="ava">
                                <div class="image" style="background: url(<?php echo e($item->reviewOwner->avatar); ?>) no-repeat 0 0;"></div>
                            </div>
                            <div class="username">
                                <span><?php echo e($item->reviewOwner->username); ?> </span><i class="fa fa-thumbs-<?php if($item->star == 1): ?>up <?php elseif($item->star == 0): ?>down <?php endif; ?>" aria-hidden="true" style="color: #a98bff;"></i>
                                <?php if(Auth::user()): ?>
                                <?php if($u->is_admin == 1): ?>
                                <?php if($item->status == 1): ?> <a href="/admin/review/status/<?php echo e($item->id); ?>/2" class="btn btn-sm btn-clean btn-icon btn-icon-md" title="Скрывать отзыв"><i class="fa fa-eye-slash" style="color: #a98bff;"></i></a> <?php endif; ?>
                                <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="date">
                            <span><?php echo e($item->created_at->todatestring()); ?></span>
                        </div>
                    </div>
                    <div class="message">
                        <p><?php echo e($item->text); ?></p>
                    </div>
               </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="send-review-request">
           <div class="wrapper">
                <div class="title center flex flex-between flex-align-center">
                    <h4>Оставить отзыв</h4>
                </div>
                <div class="form-request">
                    <form action="/review/post" class="flex flex-between flex-wrap">
                        <div class="shribe-review">
                            <div class="bx-input">
                                <label>Написать отзыв</label>
                                <textarea name="review" id="review" maxlength="255" placeholder="Ваш отзыв..."></textarea>
                            </div>
                        </div>
                        <div class="sorting">
                            <div class="bx-input">
                                <label>Отзыв</label>
                                <select name="star" id="star" value="0">
                                    <option value="1">Положительный</option>
                                    <option value="0">Отрицательный</option>
                                </select>
                            </div>
                            <div class="bx-input">
                                <label>Привязать к скрипту</label>
                                <select name="script" id="script">
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($product->id); ?>"><?php echo e($product->title); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="bx-input">
                                <button type="submit">Опубликовать</button>
                            </div>
                        </div>
                    </form>
                </div>
           </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/a0330028/domains/webgamestore.ru/public_html/resources/views/pages/reviews.blade.php ENDPATH**/ ?>