<?php $__env->startSection('content'); ?>
<div class="header-title">
   <div class="wrapper">
        <span>Каталог скриптов</span>
   </div>
</div>

<section class="info">
    <div class="wrapper">
        <div class="block scripts">
            <div class="title flex flex-between flex-align-center">
                <h4>Популярные товары</h4>
            </div>
            <div class="list-items">
                <a href="#" id="prev"></a>
                <div class="scroll" id="slider_cat">
                    <?php $__currentLoopData = $top; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="/product/<?php echo e($list->id); ?>" class="item">
                        <div class="bg" style="background: url(<?php echo e($list->image); ?>) no-repeat center center/ cover;"></div>
                        <div class="info">
                           <div class="top">
                                <div class="category">
                                    <span>Категория:</span><b><?php echo e($list->productCategory->name); ?></b>
                                </div>
                                <div class="descr">
                                    <span><?php echo e($list->title); ?></span>
                                </div>
                           </div>
                           <div class="price">
                               <span><?php echo e($list->price); ?></span><b>РУБ</b>
                           </div>
                        </div>
                    </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <a href="#" id="next"></a>
            </div>
        </div>
    </div>
    <div class="block scripts tabs" style="margin-top: 90px;">
        <div class="wrapper">
            <div class="title flex flex-center flex-align-center">
                <h4>Все скрипты</h4>
            </div>
        </div>
        <div class="tabs-selector">
            <div class="wrapper">
                <ul>
                    <li class="<?php echo e(Request::is('catalog') ? 'active' : ''); ?>"><a href="/catalog">Все скрипты</a></li>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="<?php echo e(Request::is('category/'.$category->id.'') ? 'active' : ''); ?>"><a href="/category/<?php echo e($category->id); ?>"><?php echo e($category->name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
        <div class="list-items">
           <div class="wrapper">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="/product/<?php echo e($item->id); ?>" class="item">
                <div class="bg" style="background: url(<?php echo e($item->image); ?>) no-repeat center center/ cover;"></div>
                <div class="info">
                   <div class="top">
                        <div class="category">
                            <span>Категория:</span><b><?php echo e($item->productCategory->name); ?></b>
                        </div>
                        <div class="descr">
                            <span><?php echo e($item->title); ?></span>
                        </div>
                   </div>
                   <div class="price">
                       <span><?php echo e($item->price); ?></span><b>РУБ</b>
                   </div>
                </div>
            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </div>
        </div>
    </div>
    <div class="wrapper">
<div class="block scripts last-buy">
            <div class="title flex flex-between flex-align-center">
                <h4>Последние покупки</h4>
            </div>
            <div class="list-items">
                <div class="scroll">
                    <?php $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lastpurchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="/product/<?php echo e($lastpurchase->product->id); ?>" class="item">
                        <div class="bg" style="background: url(<?php echo e($lastpurchase->product->image); ?>) no-repeat center center/ cover;"></div>
                        <div class="info">
                           <div class="top">
                                <div class="descr">
                                    <span><?php echo e($lastpurchase->product->title); ?></span>
                                </div>
                           </div>
                        </div>
                    </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</section>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/a0330028/domains/webgamestore.ru/public_html/resources/views/pages/catalog.blade.php ENDPATH**/ ?>