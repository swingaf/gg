<?php $__env->startSection('content'); ?>
<div class="kt-subheader kt-grid__item" id="kt_subheader">
	<div class="kt-subheader__main">
		<h3 class="kt-subheader__title">Редактирование товара</h3>
	</div>
</div>

<div class="kt-content  kt-grid__item kt-grid__item--fluid" id="kt_content">
	<div class="row">
		<div class="col-xl-4">
			<div class="kt-portlet kt-portlet--fit kt-portlet--head-lg kt-portlet--head-overlay">
				<div class="kt-portlet__head kt-portlet__space-x">
					<div class="kt-portlet__head-label" style="width: 100%;">
						<h3 class="kt-portlet__head-title text-center" style="width: 100%;">
							<?php echo e($product->title); ?>

						</h3>
					</div>
				</div>
				<div class="kt-portlet__body" style="margin-top: 5px;">
					<div class="kt-widget28">
						<div class="kt-widget28__visual" style="background: url(<?php echo e($product->image); ?>) bottom center no-repeat"></div>
						<div class="kt-widget28__wrapper kt-portlet__space-x">
							<div class="tab-content">
								<div id="menu11" class="tab-pane active">
									<div class="kt-widget28__tab-items">
										<div class="kt-widget12">
											<div class="kt-widget12__content">
												<div class="kt-widget12__item">
													<div class="kt-widget12__info text-center">
														<span class="kt-widget12__desc">Количество покупок</span>
														<span class="kt-widget12__value"><?php echo e($purchasescount); ?></span>
													</div>
													<div class="kt-widget12__info text-center">
														<span class="kt-widget12__desc">Заработано на товаре</span>
														<span class="kt-widget12__value"><?php echo e($purchasessum); ?> р.</span>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-xl-8">
			<div class="kt-portlet">
				<div class="kt-portlet__head">
					<div class="kt-portlet__head-label">
						<h3 class="kt-portlet__head-title">
							Информация о продукте
						</h3>
					</div>
				</div>
				<form class="kt-form" method="post" action="/admin/product/save">
					<div class="kt-portlet__body">
						<input name="id" value="<?php echo e($product->id); ?>" type="hidden">
						<div class="form-group row">
							<div class="col-lg-6">
								<label>Название:</label>
								<input type="text" name="title" class="form-control" value="<?php echo e($product->title); ?>">
							</div>
							<div class="col-lg-6">
								<label class="">Категория:</label>
								<select class="form-control" name="category">
									<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($category->id); ?>" <?php if($product->productCategory->id == $category->id): ?> selected <?php endif; ?>><?php echo e($category->name); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
							</div>
						</div>
						<div class="form-group row">
							<div class="col-lg-6">
								<label>Цена:</label>
								<div class="kt-input-icon">
									<input type="text" class="form-control" name="price" value="<?php echo e($product->price); ?>">
									<span class="kt-input-icon__icon kt-input-icon__icon--right"><span><i class="la la-rub"></i></span></span>
								</div>
							</div>
							<div class="col-lg-6">
								<label>Ссылка на картинку:</label>
								<input type="text" class="form-control" name="image" value="<?php echo e($product->image); ?>">
							</div>
						</div>
						<div class="form-group row">
							<div class="col-lg-6">
								<label>Ссылка на скачку:</label>
								<div class="kt-input-icon">
									<input type="text" class="form-control" name="download_link" value="<?php echo e($product->download_link); ?>">
								</div>
							</div>
							<div class="col-lg-6">
								<label>Пароль для скачки:</label>
								<input type="text" class="form-control" name="download_pass" value="<?php echo e($product->download_pass); ?>">
							</div>
						</div>
						<div class="form-group row">
							<div class="col-lg-12">
								<label class="">Описание:</label>
								<textarea type="text" class="form-control" name="description"><?php echo e($product->description); ?></textarea>
							</div>
						</div>
					</div>
					<div class="kt-portlet__foot kt-portlet__foot--solid">
						<div class="kt-form__actions">
							<div class="row">
								<div class="col-12">
									<button type="submit" class="btn btn-brand">Сохранить</button>
								</div>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
	<div class="kt-content kt-grid__item kt-grid__item--fluid" id="kt_content">
		<div class="kt-portlet kt-portlet--mobile">
			<div class="kt-portlet__head kt-portlet__head--lg">
				<div class="kt-portlet__head-label">
					<span class="kt-portlet__head-icon">
						<span class="kt-menu__link-icon">
									<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1" class="kt-svg-icon">
													<g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
															<rect id="bound" x="0" y="0" width="24" height="24"></rect>
															<path d="M8,3 L8,3.5 C8,4.32842712 8.67157288,5 9.5,5 L14.5,5 C15.3284271,5 16,4.32842712 16,3.5 L16,3 L18,3 C19.1045695,3 20,3.8954305 20,5 L20,21 C20,22.1045695 19.1045695,23 18,23 L6,23 C4.8954305,23 4,22.1045695 4,21 L4,5 C4,3.8954305 4.8954305,3 6,3 L8,3 Z" id="Combined-Shape" fill="#000000" opacity="0.3"></path>
															<path d="M11,2 C11,1.44771525 11.4477153,1 12,1 C12.5522847,1 13,1.44771525 13,2 L14.5,2 C14.7761424,2 15,2.22385763 15,2.5 L15,3.5 C15,3.77614237 14.7761424,4 14.5,4 L9.5,4 C9.22385763,4 9,3.77614237 9,3.5 L9,2.5 C9,2.22385763 9.22385763,2 9.5,2 L11,2 Z" id="Combined-Shape" fill="#000000"></path>
															<rect id="Rectangle-152" fill="#000000" opacity="0.3" x="10" y="9" width="7" height="2" rx="1"></rect>
															<rect id="Rectangle-152-Copy-2" fill="#000000" opacity="0.3" x="7" y="9" width="2" height="2" rx="1"></rect>
															<rect id="Rectangle-152-Copy-3" fill="#000000" opacity="0.3" x="7" y="13" width="2" height="2" rx="1"></rect>
															<rect id="Rectangle-152-Copy" fill="#000000" opacity="0.3" x="10" y="13" width="7" height="2" rx="1"></rect>
															<rect id="Rectangle-152-Copy-5" fill="#000000" opacity="0.3" x="7" y="17" width="2" height="2" rx="1"></rect>
															<rect id="Rectangle-152-Copy-4" fill="#000000" opacity="0.3" x="10" y="17" width="7" height="2" rx="1"></rect>
													</g>
										</svg>
						</span>
					</span>
					<h3 class="kt-portlet__head-title">
						Последние покупки товара
					</h3>
				</div>
			</div>
			<div class="kt-portlet__body">
				<br>
				<table class="table table-striped- table-bordered table-hover table-checkable">
					<thead>
						<tr>
							<th>ID</th>
							<th>Название</th>
							<th>Пользователь</th>
							<th>Цена</th>
							<th>Статус</th>
							<th>Действия</th>
						</tr>
					</thead>
					<tbody>
					<?php $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($purchase->id); ?></td>
						<td><?php echo e($purchase->product->title); ?></td>
						<td><a href="/admin/user/<?php echo e($purchase->owner->id); ?>"><?php echo e($purchase->owner->username); ?></a></td>
						<td><?php echo e($purchase->price); ?><i class="la la-rub" aria-hidden="true" style="color: #5d78ff;"></i></td>
						<td>
							<?php if($purchase->status == '0'): ?> <span class="kt-badge kt-badge--danger kt-badge--inline kt-badge--pill">Заказ создан</span> <?php elseif($purchase->status == '1'): ?> <span class="kt-badge kt-badge--info kt-badge--inline kt-badge--pill">Оплачено</span> <?php elseif($purchase->status == '2'): ?> <span class="kt-badge kt-badge--success kt-badge--inline kt-badge--pill">Обработано</span> <?php else: ?> Ошибка <?php endif; ?>
						</td>
						<td><a href="/admin/purchase/<?php echo e($purchase->id); ?>" class="btn btn-sm btn-clean btn-icon btn-icon-md" title="Просмотр"><i class="la la-eye"></i></a></td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>

			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/a0330028/domains/webgamestore.ru/public_html/resources/views/admin/product.blade.php ENDPATH**/ ?>