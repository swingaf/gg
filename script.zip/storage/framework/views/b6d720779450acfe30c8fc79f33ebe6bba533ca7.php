<?php $__env->startSection('content'); ?>
<script type="text/javascript" src="/js/chart.min.js"></script>
<div class="kt-subheader kt-grid__item" id="kt_subheader">
	<div class="kt-subheader__main">
		<h3 class="kt-subheader__title">Статистика</h3>
	</div>
	<div class="kt-subheader__toolbar">

    </div>
</div>

<div class="kt-content  kt-grid__item kt-grid__item--fluid" id="kt_content">
	<div class="kt-portlet">
		<div class="kt-portlet__body  kt-portlet__body--fit">
			<div class="row row-no-padding row-col-separator-xl">

				<div class="col-md-12 col-lg-6 col-xl-3">
					<!--begin::Total Profit-->
					<div class="kt-widget24">
						<div class="kt-widget24__details">
							<div class="kt-widget24__info">
								<h4 class="kt-widget24__title">
									Пополнений на
								</h4>
								<span class="kt-widget24__desc">
									за сегодня
								</span>
							</div>

							<span class="kt-widget24__stats kt-font-success">
								<?php echo e($pay_today); ?><i class="la la-rub"></i>
							</span>
						</div>
					</div>
					<!--end::Total Profit-->
				</div>

				<div class="col-md-12 col-lg-6 col-xl-3">
					<!--begin::New Feedbacks-->
					<div class="kt-widget24">
						<div class="kt-widget24__details">
							<div class="kt-widget24__info">
								<h4 class="kt-widget24__title">
									Пополнений на
								</h4>
								<span class="kt-widget24__desc">
									за 7 дней
								</span>
							</div>

							<span class="kt-widget24__stats kt-font-success">
							   <?php echo e($pay_week); ?><i class="la la-rub"></i>
							</span>
						</div>
					</div>
					<!--end::New Feedbacks-->
				</div>

				<div class="col-md-12 col-lg-6 col-xl-3">
					<!--begin::New Orders-->
					<div class="kt-widget24">
						<div class="kt-widget24__details">
							<div class="kt-widget24__info">
								<h4 class="kt-widget24__title">
									Пополнений на
								</h4>
								<span class="kt-widget24__desc">
									за месяц
								</span>
							</div>

							<span class="kt-widget24__stats kt-font-success">
								<?php echo e($pay_month); ?><i class="la la-rub"></i>
							</span>
						</div>
					</div>
					<!--end::New Orders-->
				</div>

				<div class="col-md-12 col-lg-6 col-xl-3">
					<!--begin::New Users-->
					<div class="kt-widget24">
						<div class="kt-widget24__details">
							<div class="kt-widget24__info">
								<h4 class="kt-widget24__title">
									Пополнений на
								</h4>
								<span class="kt-widget24__desc">
									за все время
								</span>
							</div>

							<span class="kt-widget24__stats kt-font-success">
								<?php echo e($pay_all); ?><i class="la la-rub"></i>
							</span>
						</div>
					</div>
					<!--end::New Users-->
				</div>

			</div>
		</div>
	</div>
	<div class="kt-portlet">
		<div class="kt-portlet__body  kt-portlet__body--fit">
			<div class="row row-no-padding row-col-separator-xl">

				<div class="col-md-12 col-lg-6 col-xl-3">
					<!--begin::Total Profit-->
					<div class="kt-widget24">
						<div class="kt-widget24__details">
							<div class="kt-widget24__info">
								<h4 class="kt-widget24__title">
									Пользователей
								</h4>
								<span class="kt-widget24__desc">
									всего
								</span>
							</div>

							<span class="kt-widget24__stats kt-font-brand">
								<?php echo e($usersCount); ?><i class="la la-user"></i>
							</span>
						</div>
					</div>
					<!--end::Total Profit-->
				</div>

				<div class="col-md-12 col-lg-6 col-xl-3">
					<!--begin::New Orders-->
					<div class="kt-widget24">
						<div class="kt-widget24__details">
							<div class="kt-widget24__info">
								<h4 class="kt-widget24__title">
									Заработано
								</h4>
								<span class="kt-widget24__desc">
									общая сумма
								</span>
							</div>

							<span class="kt-widget24__stats kt-font-danger">
								<?php echo e($earned); ?><i class="la la-rub"></i>
							</span>
						</div>
					</div>
					<!--end::New Orders-->
				</div>


				<div class="col-md-12 col-lg-6 col-xl-3">
					<!--begin::New Orders-->
					<div class="kt-widget24">
						<div class="kt-widget24__details">
							<div class="kt-widget24__info">
								<h4 class="kt-widget24__title">
									Заказов оплачено
								</h4>
								<span class="kt-widget24__desc">
									в ожидании
								</span>
							</div>

							<span class="kt-widget24__stats kt-font-warning">
								<?php echo e($payed); ?><i class="la la-clock-o"></i>
							</span>
						</div>
					</div>
					<!--end::New Orders-->
				</div>

				<div class="col-md-12 col-lg-6 col-xl-3">
					<!--begin::New Orders-->
					<div class="kt-widget24">
						<div class="kt-widget24__details">
							<div class="kt-widget24__info">
								<h4 class="kt-widget24__title">
									Отзывов на модерации
								</h4>
								<span class="kt-widget24__desc">
									в ожидании
								</span>
							</div>

							<span class="kt-widget24__stats kt-font-<?php if($reviews > 0): ?>warning <?php elseif($reviews == 0): ?>success <?php endif; ?>">
								<?php echo e($reviews); ?><?php if($reviews > 0): ?> <i class="la la-clock-o"> <?php elseif($reviews == 0): ?> <i class="la la-check"> <?php endif; ?></i>
							</span>
						</div>
					</div>
					<!--end::New Orders-->
				</div>

			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-xl-4">
			<div class="kt-portlet">
				<div class="kt-portlet__head">
					<div class="kt-portlet__head-label">
						<h3 class="kt-portlet__head-title">
							Последние пополнения
						</h3>
					</div>
				</div>
				<div class="kt-portlet__body">
					<div class="kt-widget3 kt-scroll" data-scroll="true" data-height="616">

						<?php $__currentLoopData = $deposits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deposit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="kt-widget3__item">
							<div class="kt-widget3__header">
								<div class="kt-widget3__user-img">
									<img class="kt-widget3__img" src="<?php echo e($deposit->avatar); ?>" alt="">
								</div>
								<div class="kt-widget3__info">
									<a href="/admin/user/<?php echo e($deposit->id); ?>" class="kt-widget3__username">
									<?php echo e($deposit->username); ?>

									</a><br>
									<span class="kt-widget3__time">
									 <?php echo e($deposit->last_ip); ?>

									</span>
								</div>
								<span class="kt-widget3__status kt-font-success">
									<?php echo e($deposit->sum); ?> <i class="la la-rub"></i>
								</span>
							</div>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					</div>
				</div>
			</div>
		</div>
		<div class="col-xl-4">
			<div class="kt-portlet">
				<div class="kt-portlet__head">
					<div class="kt-portlet__head-label">
						<h3 class="kt-portlet__head-title">
							Последние покупки
						</h3>
					</div>
				</div>
				<div class="kt-portlet__body">
					<div class="kt-widget3 kt-scroll" data-scroll="true" data-height="616">

						<?php $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="kt-widget3__item">
							<div class="kt-widget3__header">
								<div class="kt-widget3__user-img">
									<img class="kt-widget3__img" src="<?php echo e($purchase->owner->avatar); ?>" alt="">
								</div>
								<div class="kt-widget3__info">
									<a href="/admin/user/<?php echo e($purchase->owner->id); ?>" class="kt-widget3__username">
								 <?php echo e($purchase->owner->username); ?>

									</a>
									<br>
									<span class="kt-widget3__time">
										<a href="/admin/product/<?php echo e($purchase->product->id); ?>">
										<?php echo e($purchase->product->title); ?>

										</a>
									</span>
								</div>
								<span class="kt-widget3__status kt-font-success">
									<?php echo e($purchase->price); ?><i class="la la-rub"></i>
								</span>
							</div>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					</div>
				</div>
			</div>
		</div>
		<div class="col-xl-4">
			<div class="kt-portlet">
				<div class="kt-portlet__head">
					<div class="kt-portlet__head-label">
						<h3 class="kt-portlet__head-title">
							Новые пользователи
						</h3>
					</div>
				</div>
				<div class="kt-portlet__body">
					<div class="kt-widget3 kt-scroll" data-scroll="true" data-height="616">

						<?php $__currentLoopData = $newusers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="kt-widget3__item">
							<div class="kt-widget3__header">
								<div class="kt-widget3__user-img">
									<img class="kt-widget3__img" src="$pay['avatar']" alt="">
								</div>
								<div class="kt-widget3__info">
									<a href="/admin/user/<?php echo e($user->id); ?>" class="kt-widget3__username">
									<?php echo e($user->username); ?>

									</a><br>
									<span class="kt-widget3__time">

									</span>
								</div>
								<span class="kt-widget3__status kt-font-success">
								<?php echo e($user->reg_ip); ?>

								</span>
							</div>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>
			</div>
		</div>
	</div>



</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/a0330028/domains/webgamestore.ru/public_html/resources/views/admin/index.blade.php ENDPATH**/ ?>