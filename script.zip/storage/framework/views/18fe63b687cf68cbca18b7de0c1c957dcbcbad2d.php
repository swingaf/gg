<?php $__env->startSection('content'); ?>
    <section class="info">
        <div class="wrapper">
            <div class="block scripts">
                <div class="title flex flex-between flex-align-center">
                    <h4>Популярные скрипты</h4>
                    <a href="/catalog"><span>Смотреть все <i class="icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M424.4 214.7L72.4 6.6C43.8-10.3 0 6.1 0 47.9V464c0 37.5 40.7 60.1 72.4 41.3l352-208c31.4-18.5 31.5-64.1 0-82.6z"/></svg></i></span></a>
                </div>
                <div class="list-items">
                    <div class="scroll">
                          <?php $__currentLoopData = $top; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <a href="/product/<?php echo e($list->id); ?>" class="item">
                            <div class="bg" style="background: url(<?php echo e($list->image); ?>) no-repeat center center/ cover;"></div>
                            <div class="info">
                               <div class="top">
                                    <div class="category">
                                        <span>Категория:</span><b><?php echo e($list->productCategory->name); ?></b>
                                    </div>
                                    <div class="descr">
                                        <span><?php echo e($list->title); ?></span>
                                    </div>
                               </div>
                               <div class="price">
                                   <span><?php echo e($list->price); ?></span><b>РУБ</b>
                               </div>
                            </div>
                        </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <div class="block scripts last-buy">
                <div class="title flex flex-between flex-align-center">
                    <h4>Последние покупки</h4>
                </div>
                <div class="list-items">
                    <div class="scroll">
                      <?php $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lastpurchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <a href="/product/<?php echo e($lastpurchase->product->id); ?>" class="item">
                          <div class="bg" style="background: url(<?php echo e($lastpurchase->product->image); ?>) no-repeat center center/ cover;"></div>
                          <div class="info">
                             <div class="top">
                                  <div class="descr">
                                      <span><?php echo e($lastpurchase->product->title); ?></span>
                                  </div>
                             </div>
                          </div>
                      </a>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/a0330028/domains/webgamestore.ru/public_html/resources/views/pages/index.blade.php ENDPATH**/ ?>