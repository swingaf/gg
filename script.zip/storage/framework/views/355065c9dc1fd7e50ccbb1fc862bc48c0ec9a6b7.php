<?php $__env->startSection('content'); ?>
<div class="kt-subheader kt-grid__item" id="kt_subheader">
	<div class="kt-subheader__main">
		<h3 class="kt-subheader__title">Настройки</h3>
	</div>
</div>

<div class="kt-content  kt-grid__item kt-grid__item--fluid" id="kt_content">
	<div class="kt-portlet kt-portlet--tabs">
		<div class="kt-portlet__head">
			<div class="kt-portlet__head-toolbar">
				<ul class="nav nav-tabs nav-tabs-line nav-tabs-line-danger nav-tabs-line-2x nav-tabs-line-right" role="tablist">
					<li class="nav-item">
						<a class="nav-link active" data-toggle="tab" href="#site" role="tab" aria-selected="true">
							Настройки сайта
						</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" data-toggle="tab" href="#pay" role="tab" aria-selected="false">
							Настройки оплаты
						</a>
					</li>
				</ul>
			</div>
		</div>
		<form class="kt-form" method="post" action="/admin/setting/save">
			<div class="kt-portlet__body">
				<div class="tab-content">
					<div class="tab-pane active" id="site" role="tabpanel">
						<div class="kt-section">
							<h3 class="kt-section__title">
								Общие настройки:
							</h3>
							<div class="form-group row">
								<div class="col-lg-4">
									<label>Доменное имя:</label>
									<input type="text" class="form-control" placeholder="domain.ru" value="<?php echo e($settings->domain); ?>" name="domain">
								</div>
								<div class="col-lg-4">
									<label>Имя сайта:</label>
									<input type="text" class="form-control" placeholder="sitename.ru" value="<?php echo e($settings->sitename); ?>" name="sitename">
								</div>
								<div class="col-lg-4">
									<label>Заголовок сайта (титул):</label>
									<input type="text" class="form-control" placeholder="sitename.ru - краткое описание" value="<?php echo e($settings->title); ?>" name="title">
								</div>
							</div>
							<div class="form-group row">
								<div class="col-lg-4">
									<label>Описание для поисковых систем:</label>
									<input type="text" class="form-control" placeholder="Описание для сайта..." value="<?php echo e($settings->desc); ?>" name="desc">
								</div>
								<div class="col-lg-4">
									<label>Ключевые слова для поисковых систем:</label>
									<input type="text" class="form-control" placeholder="сайт, имя, домен и тд..." value="<?php echo e($settings->keys); ?>" name="keys">
								</div>
								<div class="col-lg-4">
									<label>Категория для услуг:</label>
									<select class="form-control" name="services_category">
										<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($category->id); ?>" <?php echo e(($settings->services_category == $category->id) ? 'selected' : ''); ?>><?php echo e($category->name); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
								</div>
							</div>
							<div class="form-group row">
								<div class="col-lg-4">
									<label>1 товар на главной странице:</label>
									<select class="form-control" name="best_1">
										<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($product->id); ?>" <?php echo e(($settings->best_1 == $product->id) ? 'selected' : ''); ?>><?php echo e($product->title); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
								</div>
								<div class="col-lg-4">
									<label>2 товар на главной странице:</label>
									<select class="form-control" name="best_2">
										<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($product->id); ?>" <?php echo e(($settings->best_2 == $product->id) ? 'selected' : ''); ?>><?php echo e($product->title); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
								</div>
								<div class="col-lg-4">
									<label>3 товар на главной странице:</label>
									<select class="form-control" name="best_3">
										<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($product->id); ?>" <?php echo e(($settings->best_3 == $product->id) ? 'selected' : ''); ?>><?php echo e($product->title); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
								</div>
							</div>
							<div class="form-group row">
								<div class="col-lg-4">
									<label>Скидка для 1 товара на главной странице:</label>
									<input type="text" class="form-control" placeholder="Скидка для 1 товара на главной странице" value="<?php echo e($settings->best_1_sale); ?>" name="best_1_sale">
								</div>
								<div class="col-lg-4">
									<label>Скидка для 2 товара на главной странице:</label>
									<input type="text" class="form-control" placeholder="Скидка для 2 товара на главной странице" value="<?php echo e($settings->best_2_sale); ?>" name="best_2_sale">
								</div>
								<div class="col-lg-4">
									<label>Скидка для 3 товара на главной странице:</label>
									<input type="text" class="form-control" placeholder="Скидка для 3 товара на главной странице" value="<?php echo e($settings->best_3_sale); ?>" name="best_3_sale">
								</div>
							</div>
						</div>
						<div class="kt-section">
							<h3 class="kt-section__title">
								Настройки соц.сетей:
							</h3>
							<div class="form-group row">
								<div class="col-lg-6">
									<label>Ссылка на группу VK:</label>
									<input type="text" class="form-control" placeholder="https://vk.com/..." value="<?php echo e($settings->vk_link); ?>" name="vk_link">
								</div>
								<div class="col-lg-6">
									<label>Ссылка на сообщения группы VK:</label>
									<input type="text" class="form-control" placeholder="https://vk.com/im?media=&sel=..." value="<?php echo e($settings->vk_support_link); ?>" name="vk_support_link">
								</div>
							</div>
							<div class="form-group row">
								<div class="col-lg-4">
									<label>Ссылка на Facebook:</label>
									<input type="text" class="form-control" placeholder="https://facebook.com/..." value="<?php echo e($settings->facebook_link); ?>" name="facebook_link">
								</div>
								<div class="col-lg-4">
									<label>Ссылка на YouTube:</label>
									<input type="text" class="form-control" placeholder="https://youtube.com/" value="<?php echo e($settings->youtube_link); ?>" name="youtube_link">
								</div>
								<div class="col-lg-4">
									<label>Ссылка на Instagram:</label>
									<input type="text" class="form-control" placeholder="https://instagram.com/" value="<?php echo e($settings->instagram_link); ?>" name="instagram_link">
								</div>
							</div>
						</div>
					</div>
					<div class="tab-pane" id="pay" role="tabpanel">
						<div class="kt-section">
							<h3 class="kt-section__title">
								Настройки платежной системы FreeKassa:
							</h3>
							<div class="form-group row">
								<div class="col-lg-4">
									<label>ID Магазина FK:</label>
									<input type="text" class="form-control" placeholder="xxxxxxx" value="<?php echo e($settings->mrh_ID); ?>" name="mrh_ID">
								</div>
								<div class="col-lg-4">
									<label>FK Secret 1:</label>
									<input type="password" class="form-control" placeholder="xxxxxxx" value="<?php echo e($settings->mrh_secret1); ?>" name="mrh_secret1">
								</div>
								<div class="col-lg-4">
									<label>FK Secret 2:</label>
									<input type="password" class="form-control" placeholder="xxxxxxx" value="<?php echo e($settings->mrh_secret2); ?>" name="mrh_secret2">
								</div>
							</div>
							<div class="form-group row">
								<div class="col-lg-6">
									<label>FK Кошелек:</label>
									<input type="text" class="form-control" placeholder="Fxxxxxx" value="<?php echo e($settings->fk_wallet); ?>" name="fk_wallet">
								</div>
								<div class="col-lg-6">
									<label>FK API Key:</label>
									<input type="text" class="form-control" placeholder="xxxxxxx" value="<?php echo e($settings->fk_api); ?>" name="fk_api">
								</div>
							</div>
							<div class="form-group row">
								<div class="col-lg-6">
									<label>Минимальная сумма пополнения:</label>
									<input type="text" class="form-control" placeholder="Введите сумму" value="<?php echo e($settings->min_dep); ?>" name="min_dep">
								</div>
								<div class="col-lg-6">
									<label>Максимальная сумма пополнения:</label>
									<input type="text" class="form-control" placeholder="Введите сумму" value="<?php echo e($settings->max_dep); ?>" name="max_dep">
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="kt-portlet__foot">
				<div class="kt-form__actions">
					<button type="submit" class="btn btn-primary">Сохранить</button>
					<button type="reset" class="btn btn-secondary">Сбросить</button>
				</div>
			</div>
		</form>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/a0330028/domains/webgamestore.ru/public_html/resources/views/admin/settings.blade.php ENDPATH**/ ?>