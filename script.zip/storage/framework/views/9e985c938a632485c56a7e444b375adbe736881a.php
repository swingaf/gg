

<?php $__env->startSection('content'); ?>
        <div class="header-title">
           <div class="wrapper">
                <span>Часто задаваемые вопросы</span>
           </div>
        </div>>
    <section class="faq">
        <div class="faq-items">
            <?php $__currentLoopData = $faq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="faq">
                <div class="wrapper">
                    <div class="heading">
                        <span><?php echo e($item->title); ?></span>
                    </div>
                    <div class="more">
                        <p><?php echo e($item->text); ?></p>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/a0330028/domains/webgamestore.ru/public_html/resources/views/pages/faq.blade.php ENDPATH**/ ?>