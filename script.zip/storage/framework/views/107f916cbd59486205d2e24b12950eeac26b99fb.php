<?php $__env->startSection('content'); ?>
    <div class="header-title">
       <div class="wrapper">
            <span>Описание товара</span>
       </div>
    </div>
    <section class="news">
        <div class="news-items">
          <div class="item">
              <div class="wrapper flex flex-between">
                  <div class="new-image">
                      <!-- <img class="img" src="<?php echo e($product->image); ?>"> -->
                      <div class="bx-input script">

                      <div class="slider flex flex-between flex-align-center flex-wrap">
                           <div class="slider-image">
                               <div class="sliders">
                                   <a href="#" id="prev_2"></a>
                                   <div class="scroll" id="sliderAbout">
                                       <div class="slider-image" style="background: url(<?php echo e($product->image); ?>)"></div>
                                       <div class="slider-image" style="background: url(https://webgamestore.ru/images/slider-image-1.png)"></div>
                                       <div class="slider-image" style="background: url(https://webgamestore.ru/images/dragonmoney.png)"></div>
                                   </div>
                                   <a href="#" id="next_2"></a>
                               </div>
                           </div>
                      </div>
                    </div>
                    <div class="buy-group">
                      <p class="product-price">Цена: <span <?php if(isset($newprice)): ?> style="text-decoration: line-through;" <?php endif; ?>><?php echo e($product->price); ?></span> <?php if(isset($newprice)): ?> <span><?php echo e($newprice); ?></span> <?php endif; ?>  р.</p>
                      <?php if(isset($newprice)): ?><p>Вы активировали промокод на скидку для этого товара.</p><?php endif; ?>
                                <a href="/product/<?php echo e($product->id); ?>/buy" class="button-buy">Купить</a>
                                <a href="/product/<?php echo e($product->id); ?>/addToBasket" class="add-to-cart purple-link">Добавить в корзину</a>
                    </div>
                  </div>
                  <div class="info">
                      <div class="heading product-heading-info">
                          <h4><?php echo e($product->title); ?></h4>
                          <div class="product-description">
                            <textarea disabled style="height: 350px; resize: none;"><?php echo e($product->description); ?></textarea>
                          </div>
        <!-- <div class="dropdown">
                              <div class="heading">
                                  Доп.услуги
                              </div>
                              <div class="drop">
                                  <div class="item active flex flex-between flex-align-center">
                                     <div class="flex flex-align-center flex-between">
                                         <span></span> <p>Установка скрипта</p>
                                     </div>
                                     <b>200 руб.</b>
                                  </div>
                                  <div class="item  flex flex-between flex-align-center">
                                     <div class="flex flex-align-center flex-between">
                                         <span></span> <p>Установка скрипта</p>
                                     </div>
                                     <b>200 руб.</b>
                                  </div>
                                  <div class="item  flex flex-between flex-align-center">
                                     <div class="flex flex-align-center flex-between">
                                         <span></span> <p>Установка скрипта</p>
                                     </div>
                                     <b>200 руб.</b>
                                  </div>
                              </div>
                          </div> -->
                      </div>
                  </div>
              </div>
          </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/a0330028/domains/webgamestore.ru/public_html/resources/views/pages/product.blade.php ENDPATH**/ ?>