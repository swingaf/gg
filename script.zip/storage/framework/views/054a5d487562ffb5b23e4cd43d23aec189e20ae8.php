<?php $__env->startSection('content'); ?>
        <div class="header-title">
           <div class="wrapper">
                <span>Ваш профиль</span>
           </div>
        </div>
    </section>
    <section class="profile">
        <div class="profile-top-bar">
            <div class="wrapper flex flex-between flex-align-center flex-wrap">
                <div class="profile flex flex-between flex-align-center flex-wrap">
                    <div class="avatar">
                        <div class="image" style="background: url(<?php echo e(Auth::user()->avatar); ?>) no-repeat center center; margin-top: -50px;"></div>
                    </div>
                    <div class="info">
                        <h4><?php echo e(Auth::user()->username); ?></h4>
                        <p><?php if(Auth::user()->is_admin == 1): ?> Администратор <?php else: ?> Пользователь <?php endif; ?></p>
                        <p>Баланс: <b><?php echo e(Auth::user()->balance); ?> <em>руб.</em></b></p>
                        <div class="form-group">
                          <form action="/promocode/activate" type="POST">
                          <input type="text" name="code" value="" placeholder="Введите промокод">
                          <button type="submit" name="button" aria-label="Активировать промокод">Активировать</button>
                        </div>
                    </div>
                </div>
                <div class="last-info">
                    <p>Последний вход с IP: <b><?php echo e(Auth::user()->last_ip); ?></b></p>
                    <a href="/logout" class="logout">Выйти</a>
                </div>
            </div>
        </div>
        <div class="profile-table">
            <div class="wrapper">
                <table>
                    <thead>
                        <tr>
                            <td>№ Заказа</td>
                            <td>Название</td>
                            <td>Цена</td>
                            <td>Категория</td>
                            <td>Куплен</td>
                            <td>Статус</td>
                            <td>Действие</td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($purchase->id); ?></td>
                            <td><?php echo e($purchase->product->title); ?> <?php if($purchase->product->download_pass): ?> (Пароль: <?php echo e($purchase->product->download_pass); ?>) <?php endif; ?></td>
                            <td><?php echo e($purchase->price); ?> <i class="fa fa-rub" aria-hidden="true"></i></td>
                            <td><?php echo e($purchase->product->productCategory->name); ?></td>
                            <td><?php echo e($purchase->created_at->toDatestring()); ?></td>
                            <td><?php if($purchase->status == 1): ?> Заказ оплачен <?php elseif($purchase->status == 2): ?> Заказ обработан <?php elseif($purchase->status == 3): ?> Средства возвращены <?php endif; ?></td>
                            <td><a href="<?php if($purchase->product->download_link): ?> <?php echo e($purchase->product->download_link); ?> <?php else: ?> <?php echo e($settings->vk_support_link); ?> <?php endif; ?>" class="download">Скачать</a></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/a0330028/domains/webgamestore.ru/public_html/resources/views/pages/profile.blade.php ENDPATH**/ ?>