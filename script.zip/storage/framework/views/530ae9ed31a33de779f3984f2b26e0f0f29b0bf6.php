<?php $__env->startSection('content'); ?>
<script src="/dash/js/dtables.js" type="text/javascript"></script>
<div class="kt-subheader kt-grid__item" id="kt_subheader">
	<div class="kt-subheader__main">
		<h3 class="kt-subheader__title">Новости</h3>
	</div>
</div>

<div class="kt-content kt-grid__item kt-grid__item--fluid" id="kt_content">
	<div class="kt-portlet kt-portlet--mobile">
		<div class="kt-portlet__head kt-portlet__head--lg">
			<div class="kt-portlet__head-label">
				<span class="kt-portlet__head-icon">
					<i class="kt-font-brand flaticon2-menu-2"></i>
				</span>
				<h3 class="kt-portlet__head-title">
					Список новостей
				</h3>
			</div>
			<div class="kt-portlet__head-toolbar">
				<div class="kt-portlet__head-wrapper">
					<div class="kt-portlet__head-actions">
						<a data-toggle="modal" href="#new" class="btn btn-success btn-elevate btn-icon-sm">
							<i class="la la-plus"></i>
							Создать
						</a>
					</div>
				</div>
			</div>
		</div>
		<div class="kt-portlet__body">

			<!--begin: Datatable -->
			<table class="table table-striped- table-bordered table-hover table-checkable" id="dtable">
				<thead>
					<tr>
						<th>ID</th>
						<th>Заголовок</th>
						<th>Текст</th>
						<th>Информация</th>
						<th>Дата</th>
						<th>Действия</th>
					</tr>
				</thead>
				<tbody>
				<?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($item->id); ?></td>
					<td><?php echo e($item->title); ?></td>
					<td><?php echo e($item->description); ?></td>
					<td><?php if($item->status == 0): ?> <span class="kt-badge kt-badge--danger kt-badge--inline kt-badge--pill">Не активна</span> <?php elseif($item->status == 1): ?> <span class="kt-badge kt-badge--success kt-badge--inline kt-badge--pill">Активна</span> <?php endif; ?></td>
					<td><?php echo e($item->created_at->format('d.m.y h:m')); ?></td>
					<td>
					<a class="btn btn-sm btn-clean btn-icon btn-icon-md" title="Редактировать" data-toggle="modal" href="#edit_<?php echo e($item->id); ?>"><i class="la la-edit"></i></a>
					<?php if($item->status == 1): ?> <a href="/admin/news/status/<?php echo e($item->id); ?>/0" class="btn btn-sm btn-clean btn-icon btn-icon-md" title="Скрывать новость"><i class="la la-eye-slash"></i></a>
					<?php elseif($item->status == 0): ?> <a href="/admin/news/status/<?php echo e($item->id); ?>/1" class="btn btn-sm btn-clean btn-icon btn-icon-md" title="Показывать новость"><i class="la la-eye"></i></a> <?php endif; ?></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>

			<!--end: Datatable -->
		</div>
	</div>
</div>
<div class="modal fade" id="new" tabindex="-1" role="dialog" aria-labelledby="newLabel" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Новая новость</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"></button>
            </div>
            <form class="kt-form-new" method="post" action="/admin/news/create">
				<div class="modal-body">
					<div class="form-group">
						<label for="title">Заголовок:</label>
						<input type="text" class="form-control" placeholder="Заголовок" name="title">
					</div>
					<div class="form-group">
						<label for="description">Текст:</label>
						<textarea type="text" class="form-control" placeholder="Текст" name="description"></textarea>
					</div>
					<div class="form-group">
						<label for="description">Ссылка на картинку:</label>
						<input type="text" class="form-control" placeholder="/.png/.jpg" name="image">
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-dismiss="modal">Закрыть</button>
					<button type="submit" class="btn btn-primary">Добавить</button>
				</div>
            </form>
        </div>
    </div>
</div>
<?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="edit_<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="newLabel" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Редактирование новости</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"></button>
            </div>
            <form class="kt-form-new" method="post" action="/admin/news/save">
				<input type="hidden" value="<?php echo e($item->id); ?>" name="id">
				<div class="modal-body">
					<div class="form-group">
						<label for="title">Заголовок:</label>
						<input type="text" class="form-control" placeholder="Заголовок" name="title" value="<?php echo e($item->title); ?>">
					</div>
					<div class="form-group">
						<label for="description">Текст:</label>
						<textarea type="text" class="form-control" placeholder="Текст" name="description" value="<?php echo e($item->description); ?>"></textarea>
					</div>
					<div class="form-group">
						<label for="description">Ссылка на картинку:</label>
						<input type="text" class="form-control" placeholder="Текст" name="image" value="<?php echo e($item->image); ?>">
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-dismiss="modal">Закрыть</button>
					<button type="submit" class="btn btn-primary">Сохранить</button>
				</div>
            </form>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/a0330028/domains/webgamestore.ru/public_html/resources/views/admin/news.blade.php ENDPATH**/ ?>