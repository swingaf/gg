﻿<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo e($settings->title); ?></title>
    <meta name='wmail-verification' content='4c766bffd87ff32e8846862d67189b48' />
    <meta name="google-site-verification" content="AwyN6CVzsgS_7lFd4Q_D1eOhKtGVa-BuHMCN4ffMX6A" />
    <meta name="yandex-verification" content="405e01d09a022aea" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://webgamestore.ru/css/styles.css">
    <link rel="stylesheet" href="https://webgamestore.ru/fonts/fonts.css">
    <link rel="stylesheet" href="https://webgamestore.ru/css/media.css">
    <link rel="icon" type="image/png" href="https://webgamestore.ru/images/wgsicon.png">
    <script type="text/javascript" src="https://webgamestore.ru/js/jquery-1.9.1.js"></script>
    <script type="text/javascript" src="https://webgamestore.ru/js/scripts.js"></script>
    <script type="text/javascript" src="https://webgamestore.ru/js/slider.js"></script>
    <script type="text/javascript" src="https://webgamestore.ru/js/jquery.bxslider.js"></script>
    <script src="https://use.fontawesome.com/7805c9fcdb.js"></script>
    <script src="//code.jivosite.com/widget.js" data-jv-id="aGsOGk7F35" async></script>
</head>
<!— Yandex.Metrika counter —>
<script type="text/javascript" >
(function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
m[i].l=1*new Date();k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
(window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");

ym(55780405, "init", {
clickmap:true,
trackLinks:true,
accurateTrackBounce:true
});
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/55780405" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!— /Yandex.Metrika counter —>
<?php if(Auth::user() && Auth::user()->ban == 1): ?>
<h4 style="color: white; font-size: 34px; text-align: center; margin-top: 5%;">Вы заблокированы на сайте!</h4>
<?php if(Auth::user()->ban_reason): ?> <h4 style="color: white; font-size: 24px; margin-top: 15px; text-align: center;">Причина: <span style="color: #a98bff;"><?php echo e(Auth::user()->ban_reason); ?> </span></h4> <?php endif; ?>
<?php else: ?>
<body>
  <div id="preloader">
      <div id="loader" class="spinner">
            <div id="shadow"></div>
            <div id="box"></div>
      </div>
  </div>
  <section class="header">
      <div class="<?php echo e(Request::is('/') ? 'slider-header' : ''); ?>">
          <header>
           <div class="wrapper flex flex-align-center flex-between">
                <a href="/" class="logo"></a>
                <div class="header-right flex flex-between flex-align-center">
                    <nav>
                        <li class="<?php echo e(Request::is('/') ? 'active' : ''); ?>"><a href="/">Главная</a></li>
                        <li class="<?php echo e(Request::is('catalog') ? 'active' : ''); ?>"><a href="/catalog">Каталог</a></li>
                        <li class="<?php echo e(Request::is('services') ? 'active' : ''); ?>"><a href="/services">Услуги</a></li>
                        <li class="<?php echo e(Request::is('reviews') ? 'active' : ''); ?>"><a href="/reviews">Отзывы</a></li>
                        <li class="<?php echo e(Request::is('garant') ? 'active' : ''); ?>"><a href="/garant">Гарантии</a></li>
                        <li class="<?php echo e(Request::is('news') ? 'active' : ''); ?>"><a href="/news">Новости</a></li>
                        <li class="<?php echo e(Request::is('faq') ? 'active' : ''); ?>"><a href="/faq">Faq</a></li>
                        <?php if(auth()->guard()->check()): ?><li><a href="#" rel="popup" data-popup="popup-pay">Пополнить баланс</a></li><?php endif; ?>
                        <li class="mobile" id="mobileMenu"><a href="#"><i class="icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M160 76V52a6 6 0 0 1 6-6h276a6 6 0 0 1 6 6v24a6 6 0 0 1-6 6H166a6 6 0 0 1-6-6zM6 210h436a6 6 0 0 0 6-6v-24a6 6 0 0 0-6-6H6a6 6 0 0 0-6 6v24a6 6 0 0 0 6 6zm0 256h436a6 6 0 0 0 6-6v-24a6 6 0 0 0-6-6H6a6 6 0 0 0-6 6v24a6 6 0 0 0 6 6zm160-128h276a6 6 0 0 0 6-6v-24a6 6 0 0 0-6-6H166a6 6 0 0 0-6 6v24a6 6 0 0 0 6 6z"/></svg></i></a></li>
                        <?php if(Auth::user() && Auth::user()->is_admin == 1): ?> <li><a href="/admin">Админ-панель</a></li> <?php endif; ?>
                    </nav>
                    <div class="user-block flex flex-between flex-align-center">
                        <a href="<?php if(auth()->guard()->check()): ?> /profile <?php else: ?> /auth/vkontakte <?php endif; ?>" class="profile"><i class="icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M224 256c70.7 0 128-57.3 128-128S294.7 0 224 0 96 57.3 96 128s57.3 128 128 128zm89.6 32h-16.7c-22.2 10.2-46.9 16-72.9 16s-50.6-5.8-72.9-16h-16.7C60.2 288 0 348.2 0 422.4V464c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48v-41.6c0-74.2-60.2-134.4-134.4-134.4z"/></svg></i></a>
                        <?php if(auth()->guard()->check()): ?><a href="#" class="basket" rel="popup" data-popup="popup-basket"><i class="icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><path d="M528.12 301.319l47.273-208C578.806 78.301 567.391 64 551.99 64H159.208l-9.166-44.81C147.758 8.021 137.93 0 126.529 0H24C10.745 0 0 10.745 0 24v16c0 13.255 10.745 24 24 24h69.883l70.248 343.435C147.325 417.1 136 435.222 136 456c0 30.928 25.072 56 56 56s56-25.072 56-56c0-15.674-6.447-29.835-16.824-40h209.647C430.447 426.165 424 440.326 424 456c0 30.928 25.072 56 56 56s56-25.072 56-56c0-22.172-12.888-41.332-31.579-50.405l5.517-24.276c3.413-15.018-8.002-29.319-23.403-29.319H218.117l-6.545-32h293.145c11.206 0 20.92-7.754 23.403-18.681z"/></svg></i><span class="basket-counter"><?php echo e($basketcount); ?></span></a><?php endif; ?>
                    </div>
                    <div class="drop">
                        <ul>
                            <li class="active"><a href="#">Главная</a></li>
                            <li><a href="/catalog">Каталог</a></li>
                            <li><a href="/services">Услуги</a></li>
                            <li><a href="/reviews">Отзывы</a></li>
                            <li><a href="/garant">Гарантии</a></li>
                            <li><a href="/news">Новости</a></li>
                            <li><a href="/faq">Faq</a></li>
                            <li><a href="#" rel="popup" data-popup="popup-pay">Пополнить баланс</a></li>
                            <?php if(Auth::user() && Auth::user()->is_admin == 1): ?> <li><a href="/admin">Админ-панель</a></li> <?php endif; ?>
                        </ul>
                    </div>
                </div>
           </div>
           <?php if(session('error')): ?>
           <div class="alert alert-danger alert-dismissible fade show" role="alert">
             <?php echo e(session('error')); ?>

             <button type="button" class="close" data-dismiss="alert" aria-label="Close" onclick="this.parentElement.style.display='none';">
               <span aria-hidden="true">&times;</span>
             </button>
           </div>
            <?php elseif(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
              <?php echo e(session('success')); ?>

              <button type="button" class="close" data-dismiss="alert" aria-label="Close" onclick="this.parentElement.style.display='none';">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <?php elseif(session('checkAccount')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
              <?php echo e(session('checkAccount')); ?>

              <button type="button" class="close" data-dismiss="alert" aria-label="Close" onclick="this.parentElement.style.display='none';">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <?php endif; ?>
           <div class="wrapper" style="display:<?php echo e(Request::is('/') ? '' : 'none'); ?>;">
               <div class="slider-tovars flex flex-between flex-wrap flex-align-start">
                   <div class="sliders">
                       <div class="slider active flex flex-between flex-align-center">
                           <div class="info-slider">
                               <div class="text discount">
                                   <span>-<?php echo e($settings->best_1_sale); ?>%</span>
                               </div>
                               <div class="text priceFrom">
                                   <span><span class="gray">Было:</span> <b><?php echo e($best_1->price+($best_1->price*$settings->best_1_sale/100)); ?> РУБ</b></span>
                               </div>
                               <div class="text price">
                                   <span><?php echo e($best_1->price); ?></span>
                                   <label>РУБ</label>
                               </div>
                               <div class="text info">
                                   <h4><?php echo e($best_1->title); ?></h4>
                                   <p><span class="gray">Категория:</span> <span><?php echo e($best_1->productCategory->name); ?></span></p>
                               </div>
                               <div class="button buy">
                                   <a href="/product/<?php echo e($best_1->id); ?>" class="buy">Купить сейчас</a>
                                   <a href="/product/<?php echo e($best_1->id); ?>" class="about">Подробнее</a>
                               </div>
                               <div class="games">
                                   <div class="head flex flex-between flex-align-center">
                                       <span>Вас тоже может заинтересовать:</span>
                                       <div class="separator"></div>
                                   </div>
                                   <div class="games-list">
                                       <?php $__currentLoopData = $random; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <div class="game">
                                           <a href="/product/<?php echo e($item->id); ?>">
                                               <div class="bg-text">
                                                   <p><?php echo e($item->title); ?></p>
                                               </div>
                                               <div class="image" style="background: url(<?php echo e($item->image); ?>) no-repeat center center / cover;"></div>
                                           </a>
                                       </div>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   </div>
                               </div>
                           </div>
                           <div class="image-slider">
                               <div class="image" style="background: url(<?php echo e($best_1->image); ?>) no-repeat center center / 100%;"></div>
                           </div>
                       </div>
                       <div class="slider active flex flex-between flex-align-center">
                           <div class="info-slider">
                               <div class="text discount">
                                   <span>-<?php echo e($settings->best_2_sale); ?>%</span>
                               </div>
                               <div class="text priceFrom">
                                   <span><span class="gray">Было:</span> <b><?php echo e($best_2->price+($best_2->price*$settings->best_2_sale/100)); ?> РУБ</b></span>
                               </div>
                               <div class="text price">
                                   <span><?php echo e($best_2->price); ?></span>
                                   <label>РУБ</label>
                               </div>
                               <div class="text info">
                                   <h4><?php echo e($best_2->title); ?></h4>
                                   <p><span class="gray">Категория:</span> <span><?php echo e($best_2->productCategory->name); ?></span></p>
                               </div>
                               <div class="button buy">
                                   <a href="/product/<?php echo e($best_2->id); ?>" class="buy">Купить сейчас</a>
                                   <a href="/product/<?php echo e($best_2->id); ?>" class="about">Подробнее</a>
                               </div>
                               <div class="games">
                                   <div class="head flex flex-between flex-align-center">
                                       <span>Вас тоже может заинтересовать:</span>
                                       <div class="separator"></div>
                                   </div>
                                   <div class="games-list">
                                     <?php $__currentLoopData = $random; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <div class="game">
                                         <a href="/product/<?php echo e($item->id); ?>">
                                             <div class="bg-text">
                                                 <p><?php echo e($item->title); ?></p>
                                             </div>
                                             <div class="image" style="background: url(<?php echo e($item->image); ?>) no-repeat center center / cover;"></div>
                                         </a>
                                     </div>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   </div>
                               </div>
                           </div>
                           <div class="image-slider">
                               <div class="image" style="background: url(<?php echo e($best_2->image); ?>) no-repeat center center / 100%;"></div>
                           </div>
                       </div>
                       <div class="slider active flex flex-between flex-align-center">
                           <div class="info-slider">
                               <div class="text discount">
                                   <span>-<?php echo e($settings->best_3_sale); ?>%</span>
                               </div>
                               <div class="text priceFrom">
                                   <span><span class="gray">Было:</span> <b><?php echo e($best_3->price+($best_3->price*$settings->best_3_sale/100)); ?> РУБ</b></span>
                               </div>
                               <div class="text price">
                                   <span><?php echo e($best_3->price); ?></span>
                                   <label>РУБ</label>
                               </div>
                               <div class="text info">
                                   <h4><?php echo e($best_3->title); ?></h4>
                                   <p><span class="gray">Категория:</span> <span><?php echo e($best_3->productCategory->name); ?></span></p>
                               </div>
                               <div class="button buy">
                                   <a href="/product/<?php echo e($best_3->id); ?>" class="buy">Купить сейчас</a>
                                   <a href="/product/<?php echo e($best_3->id); ?>" class="about">Подробнее</a>
                               </div>
                               <div class="games">
                                   <div class="head flex flex-between flex-align-center">
                                       <span>Вас тоже может заинтересовать:</span>
                                       <div class="separator"></div>
                                   </div>
                                   <div class="games-list">
                                     <?php $__currentLoopData = $random; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <div class="game">
                                         <a href="/product/<?php echo e($item->id); ?>">
                                             <div class="bg-text">
                                                 <p><?php echo e($item->title); ?></p>
                                             </div>
                                             <div class="image" style="background: url(<?php echo e($item->image); ?>) no-repeat center center / cover;"></div>
                                         </a>
                                     </div>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   </div>
                               </div>
                           </div>
                           <div class="image-slider">
                               <div class="image" style="background: url(<?php echo e($best_3->image); ?>) no-repeat center center / 100%;"></div>
                           </div>
                       </div>
                   </div>
                   <div class="arrows">
                       <ul class="slider-button">
                           <li class="active">
                               <a href="#">
                                   <span>01</span><span class="progress"></span>
                               </a>
                           </li>
                           <li>
                               <a href="#">
                                   <span>02</span><span class="progress"></span>
                               </a>
                           </li>
                           <li>
                               <a href="#">
                                   <span>03</span><span class="progress"></span>
                               </a>
                           </li>
                       </ul>
                       <a class="slide_next" onclick="next()"><i class="icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M424.4 214.7L72.4 6.6C43.8-10.3 0 6.1 0 47.9V464c0 37.5 40.7 60.1 72.4 41.3l352-208c31.4-18.5 31.5-64.1 0-82.6z"/></svg></i></a>
                   </div>
                   <a class="slide_next_two" onclick="next()"><i class="icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M424.4 214.7L72.4 6.6C43.8-10.3 0 6.1 0 47.9V464c0 37.5 40.7 60.1 72.4 41.3l352-208c31.4-18.5 31.5-64.1 0-82.6z"/></svg></i></a>
               </div>
           </div>
         </div>
        </header>
      </section>
        <?php echo $__env->yieldContent('content'); ?>
        <div class="overlay">
          <div class="popup popup-about">
              <div class="title">
                  <b>Описание товара</b>
              </div>
              <div class="modal-content">
                  <div class="bx-input script">
                     <div class="slider flex flex-between flex-align-center flex-wrap">
                          <div class="slider-image">
                              <div class="sliders">
                                  <a href="#" id="prev_2"></a>
                                  <div class="scroll" id="sliderAbout">
                                      <div class="slider-image" style="background: url(https://webgamestore.ru/images/dragonmoney.png)"></div>
                                      <div class="slider-image" style="background: url(https://webgamestore.ru/images/slider-image-1.png)"></div>
                                      <div class="slider-image" style="background: url(https://webgamestore.ru/images/dragonmoney.png)"></div>
                                  </div>
                                  <a href="#" id="next_2"></a>
                              </div>
                          </div>
                          <div class="info-script">
                              <h4>KEYS-UP - кейсы с ключами</h4>
                              <h4>Цена: <b>2999</b> р.</h4>
                              <div class="dropdown">
                                  <div class="heading">
                                      Доп.услуги
                                  </div>
                                  <div class="drop">
                                      <div class="item active flex flex-between flex-align-center">
                                         <div class="flex flex-align-center flex-between">
                                             <span></span> <p>Установка скрипта</p>
                                         </div>
                                         <b>200 руб.</b>
                                      </div>
                                      <div class="item  flex flex-between flex-align-center">
                                         <div class="flex flex-align-center flex-between">
                                             <span></span> <p>Установка скрипта</p>
                                         </div>
                                         <b>200 руб.</b>
                                      </div>
                                      <div class="item  flex flex-between flex-align-center">
                                         <div class="flex flex-align-center flex-between">
                                             <span></span> <p>Установка скрипта</p>
                                         </div>
                                         <b>200 руб.</b>
                                      </div>
                                  </div>
                              </div>
                              <div class="buy">
                                  <button type="submit">Купить</button>
                              </div>
                          </div>
                     </div>
                  </div>
                  <div class="bx-input descr">
                      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Veritatis nostrum, saepe odio voluptatum repellat ipsum deserunt numquam totam earum, repudiandae, vel perspiciatis iure beatae. Fugit mollitia explicabo veritatis porro, libero iusto praesentium ut voluptates, autem, ex deleniti labore, qui laboriosam.</p>
                      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quam, in! Repudiandae, tempore veritatis repellat a, nam eius blanditiis autem velit dignissimos soluta voluptates! Doloribus impedit omnis, officia repellendus fuga beatae autem nihil minus veritatis laboriosam, reiciendis dignissimos atque, accusantium non rerum neque. Eligendi ipsum molestias incidunt, sapiente omnis iste ipsa tempora libero, ratione repudiandae vitae, blanditiis iure non necessitatibus atque.</p>
                  </div>
              </div>
          </div>
            <div class="popup popup-pay">
                <div class="title">
                    <b>Пополнение баланса</b>
                </div>
                <form action="/pay" method="GET">
                <div class="modal-content">
                    <div class="bx-input">
                        <label>Введите сумму</label>
                        <input type="text" class="input-sum" name="num" min="<?php echo e($settings->min_dep); ?>" placeholder="Пример: 200 руб.">
                    </div>
                    <div class="bx-input">
                        <label>Способ оплаты</label>
                        <select>
                            <option value="1">Free-Kassa</option>
                            <option value="0" disabled>Яндекс.Деньги (отключено)</option>
                            <option value="0" disabled>Qiwi (отключено)</option>
                            <option value="0" disabled>Master card/Visa (отключено)</option>
                        </select>
                    </div>
                    <div class="bx-input">
                        <div class="usl flex flex-between">
                            <span>Минимум: <b><?php echo e($settings->min_dep); ?></b> руб.</span>
                            <span>Максимум: <b><?php echo e($settings->max_dep); ?></b> руб.</span>
                        </div>
                    </div>
                    <div class="bx-input go">
                        <button type="submit">Перейти к оплате</button>
                    </div>
                </div>
                </form>
            </div>
            <?php if(Auth::user()): ?>
            <div class="popup popup-basket">
                <div class="title">
                    <b>Корзина</b>
                </div>
                <div class="modal-content">
                    <div class="bx-input tovars">
                       <div class="items-title flex flex-end">
                           <?php if(isset($data)): ?>
                           <div class="names">
                               <div class="name_1">Цена</div>
                               <div class="name_2">Скидка</div>
                               <div class="name_2">Действия</div>
                           </div>
                           <?php endif; ?>
                       </div>
                        <div class="items">
                            <?php if(isset($data)): ?>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="item flex flex-between">
                               <div class="left flex flex-between flex-align-center">
                                    <div class="image">
                                        <div class="img" style="background: url(<?php echo e($info['product_image']); ?>) no-repeat center center;"></div>
                                    </div>
                                    <div class="info">
                                        <b><a href="/product/<?php echo e($info['product_id']); ?>"><?php echo e($info['product_title']); ?></a></b>
                                        <p>Категория: <a style="color: #A98BFF;" href="/category/<?php echo e($info['category_id']); ?>"><?php echo e($info['category_name']); ?></a></p>
                                    </div>
                               </div>
                               <div class="right">
                                   <?php if($info['product_status'] == 1): ?>
                                   <?php if($info['product_sale'] != 0): ?>
                                   <div class="price"><b><span style="text-decoration: line-through;"><?php echo e($info['product_price']); ?></span> <?php echo e($info['product_newprice']); ?></b></div>
                                   <?php else: ?>
                                   <div class="price"><b><?php echo e($info['product_price']); ?></b></div>
                                   <?php endif; ?>
                                   <div class="sale"><b><?php echo e($info['product_sale']); ?>%</b></div>
                                   <div class="actions"><b><a href="/product/<?php echo e($info['product_id']); ?>/removeFromBasket" title="Удалить"><i class="fa fa-trash"></i></a></b></div>
                                   <?php else: ?>
                                  <div class="info"><b>Товар не активен</b></div>
                                  <?php endif; ?>
                               </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                            <div style="text-align: center;" class="total-items-basket">
                              <p>Ваша корзина пуста</p>
                            </div>
                            <?php endif; ?>
                            <div class="total-items-basket">
                              <p>Всего в корзине: <span><?php echo e($basketcount); ?></span>позиций</p>
                            </div>
                        </div>
                    </div>
                    <div class="bx-input right">
                       <form action="/buyFromBasket">
                        <span>Ваш баланс: <b><?php echo e($u->balance); ?></b> рублей</span>
                        <?php if(isset($data)): ?><button type="submit">Перейти к оплате</button><?php endif; ?>
                      </form>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
<footer>
    <div class="navbar-footer">
        <div class="wrapper flex flex-center flex-align-center">
            <div class="social flex flex-start flex-align-center">
                <span>Мы в социальных сетях:</span>
                <div class="socials">
                    <a href="<?php echo e($settings->vk_link); ?>"><i class="icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><path d="M545 117.7c3.7-12.5 0-21.7-17.8-21.7h-58.9c-15 0-21.9 7.9-25.6 16.7 0 0-30 73.1-72.4 120.5-13.7 13.7-20 18.1-27.5 18.1-3.7 0-9.4-4.4-9.4-16.9V117.7c0-15-4.2-21.7-16.6-21.7h-92.6c-9.4 0-15 7-15 13.5 0 14.2 21.2 17.5 23.4 57.5v86.8c0 19-3.4 22.5-10.9 22.5-20 0-68.6-73.4-97.4-157.4-5.8-16.3-11.5-22.9-26.6-22.9H38.8c-16.8 0-20.2 7.9-20.2 16.7 0 15.6 20 93.1 93.1 195.5C160.4 378.1 229 416 291.4 416c37.5 0 42.1-8.4 42.1-22.9 0-66.8-3.4-73.1 15.4-73.1 8.7 0 23.7 4.4 58.7 38.1 40 40 46.6 57.9 69 57.9h58.9c16.8 0 25.3-8.4 20.4-25-11.2-34.9-86.9-106.7-90.3-111.5-8.7-11.2-6.2-16.2 0-26.2.1-.1 72-101.3 79.4-135.6z"/></svg></i></a>
                    <a href="<?php echo e($settings->facebook_link); ?>"><i class="icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M448 56.7v398.5c0 13.7-11.1 24.7-24.7 24.7H309.1V306.5h58.2l8.7-67.6h-67v-43.2c0-19.6 5.4-32.9 33.5-32.9h35.8v-60.5c-6.2-.8-27.4-2.7-52.2-2.7-51.6 0-87 31.5-87 89.4v49.9h-58.4v67.6h58.4V480H24.7C11.1 480 0 468.9 0 455.3V56.7C0 43.1 11.1 32 24.7 32h398.5c13.7 0 24.8 11.1 24.8 24.7z"/></svg></i></a>
                    <a href="<?php echo e($settings->instagram_link); ?>"><i class="icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M224.1 141c-63.6 0-114.9 51.3-114.9 114.9s51.3 114.9 114.9 114.9S339 319.5 339 255.9 287.7 141 224.1 141zm0 189.6c-41.1 0-74.7-33.5-74.7-74.7s33.5-74.7 74.7-74.7 74.7 33.5 74.7 74.7-33.6 74.7-74.7 74.7zm146.4-194.3c0 14.9-12 26.8-26.8 26.8-14.9 0-26.8-12-26.8-26.8s12-26.8 26.8-26.8 26.8 12 26.8 26.8zm76.1 27.2c-1.7-35.9-9.9-67.7-36.2-93.9-26.2-26.2-58-34.4-93.9-36.2-37-2.1-147.9-2.1-184.9 0-35.8 1.7-67.6 9.9-93.9 36.1s-34.4 58-36.2 93.9c-2.1 37-2.1 147.9 0 184.9 1.7 35.9 9.9 67.7 36.2 93.9s58 34.4 93.9 36.2c37 2.1 147.9 2.1 184.9 0 35.9-1.7 67.7-9.9 93.9-36.2 26.2-26.2 34.4-58 36.2-93.9 2.1-37 2.1-147.8 0-184.8zM398.8 388c-7.8 19.6-22.9 34.7-42.6 42.6-29.5 11.7-99.5 9-132.1 9s-102.7 2.6-132.1-9c-19.6-7.8-34.7-22.9-42.6-42.6-11.7-29.5-9-99.5-9-132.1s-2.6-102.7 9-132.1c7.8-19.6 22.9-34.7 42.6-42.6 29.5-11.7 99.5-9 132.1-9s102.7-2.6 132.1 9c19.6 7.8 34.7 22.9 42.6 42.6 11.7 29.5 9 99.5 9 132.1s2.7 102.7-9 132.1z"/></svg></i></a>
                    <a href="<?php echo e($settings->youtube_link); ?>"><i class="icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><path d="M549.655 124.083c-6.281-23.65-24.787-42.276-48.284-48.597C458.781 64 288 64 288 64S117.22 64 74.629 75.486c-23.497 6.322-42.003 24.947-48.284 48.597-11.412 42.867-11.412 132.305-11.412 132.305s0 89.438 11.412 132.305c6.281 23.65 24.787 41.5 48.284 47.821C117.22 448 288 448 288 448s170.78 0 213.371-11.486c23.497-6.321 42.003-24.171 48.284-47.821 11.412-42.867 11.412-132.305 11.412-132.305s0-89.438-11.412-132.305zm-317.51 213.508V175.185l142.739 81.205-142.739 81.201z"/></svg></i></a>
                </div>
            </div>
        </div>
    </div>
    <div class="footer">
       <div class="wrapper flex flex-between flex-wrap">
            <a href="#" class="logo"></a>
            <div class="menu-s">
                <nav class="menu">
                    <div class="heading">
                        Главная
                    </div>
                    <li><a href="/">Главная</a></li>
                    <li><a href="/catalog">Каталог</a></li>
                    <li><a href="/news">Новости</a></li>
                    <li><a href="/services">Услуги</a></li>
                </nav>
                <nav class="menu">
                    <div class="heading">
                        Помощь
                    </div>
                    <li><a href="/faq">Faq</a></li>
                    <li><a href="/reviews">Отзывы</a></li>
                    <li><a href="/garant">Гарантии</a></li>
                </nav>
                <nav class="menu">
                    <div class="heading">
                        Помощь
                    </div>
                    <li><a href="<?php echo e($settings->vk_link); ?>">Вконтакте</a></li>
                    <li><a href="<?php echo e($settings->facebook_link); ?>">Telegram</a></li>
                    <li><a href="<?php echo e($settings->instagram_link); ?>">Instagram</a></li>
                    <li><a href="<?php echo e($settings->youtube_link); ?>">YouTube</a></li>
                </nav>
            </div>
       </div>
    </div>
</footer>
</body>
</html>
<?php endif; ?>
<?php /**PATH /home/a0330028/domains/webgamestore.ru/public_html/resources/views/layout.blade.php ENDPATH**/ ?>