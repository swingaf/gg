<?php $__env->startSection('content'); ?>
    <div class="header-title">
       <div class="wrapper">
            <span>Наши услуги</span>
       </div>
    </div>
    <section class="info">
        <div class="block scripts tabs">
            <div class="wrapper">
                <div class="title flex flex-center flex-align-center">
                    <h4>Все Услуги</h4>
                </div>
            </div>
            <div class="list-items">
               <div class="wrapper">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="/product/<?php echo e($product->id); ?>" class="item">
                    <div class="bg" style="background: url(<?php echo e($product->image); ?>) no-repeat center center/ cover;"></div>
                    <div class="info">
                       <div class="top">
                            <div class="category">
                                <span>Категория:</span><b><?php echo e($product->productCategory->name); ?></b>
                            </div>
                            <div class="descr">
                                <span><?php echo e($product->title); ?></span>
                            </div>
                       </div>
                       <div class="price">
                           <span><?php echo e($product->price); ?></span><b>РУБ</b>
                       </div>
                    </div>
                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/a0330028/domains/webgamestore.ru/public_html/resources/views/pages/services.blade.php ENDPATH**/ ?>