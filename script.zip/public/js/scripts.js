var col = 1;
function next() {
    col = col + 1;
    slide();
}
function slide() {
    if (col > $('.header .slider-tovars .sliders .slider').size()) {
        col = 1;
    }
    if (col == 0) {
        col = $('.header .slider-tovars .sliders .slider').size();
    }
    $('.header .slider-tovars .sliders .slider').hide().removeClass('active');
    $('.header .slider-tovars .arrows ul li').removeClass('active');
    $('.header .slider-tovars .sliders .slider:nth-child(' + col + ')').fadeIn(1500).addClass('active');
    $('.header .slider-tovars .sliders .slider:nth-child(' + col + ')').parent().parent().find('.arrows ul li:nth-child(' + col + ')').addClass('active');
}

$(document).ready(function(){
        $(document).bind('click', function(e) {
        var $clicked = $(e.target);
        if (! $clicked.parents().hasClass("#mobileMenu")) {
            $("body").removeClass('opened');
        }
        else return false;
    });
    
    $('#mobileMenu').click(function(e){
       if($('body').hasClass('opened')) {
           $('body').removeClass('opened');
       } else {
           $('body').addClass('opened');
       }
        return false
    });
});

$(document).ready(function() {
    
    $(document).ready(function(){
      $('#preloader').fadeOut(1500);
    });
    
	$('.close').click(function(e) {
        $('.popup, .overlay, body').removeClass('active');
		return false;
    });
	$('.overlay').click(function(e) {
        var target = e.target || e.srcElement;
		if(!target.className.search('overlay')) {
			$('.overlay, .popup, body').removeClass('active');
		} 
    });	
	$('[rel=popup]').click(function(e) {
    	showPopup($(this).attr('data-popup'));
		return false
    });
    
    $('.header .slider-tovars .sliders .slider').not(':first').hide();
    if ($('.header .slider-tovars .sliders').length) {
        setInterval(function() {
            $('.header .slider-tovars .arrows .slide_next').trigger('click');
        }, 15000);
    }
    
    $('section.faq .faq-items .faq .heading').click(function(e){
        e.preventDefault();
       if($(this).parent().parent().hasClass('opened')) {
            $(this).parent().parent().removeClass('opened');
       } else {
           $('section.faq .faq-items .faq.opened').removeClass('opened');
           $(this).parent().parent().addClass('opened');
       }
    });
});

function showPopup(el) {
	if($('.popup').is('.active')) {
		$('.popup').removeClass('active');	
	}
	$('.overlay, body, .popup.'+el).addClass('active');
}
