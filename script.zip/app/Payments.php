<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Payments extends Model
{
    protected $table = 'payments';

	protected $fillable = ['user_id', 'secret', 'merchant_id', 'order_id', 'sum', 'status'];

    protected $hidden = ['created_at', 'updated_at'];

    public function deposit(){
        return $this->belongsTo('App\User','user_id');
    }


}
