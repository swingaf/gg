<?php namespace App;

use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;

class Products extends Model
{

    protected $table = 'products';

    protected $fillable = ['title', 'image', 'price', 'description', 'category_id', 'purchases', 'download_pass', 'download_link', 'status'];

    protected $hidden = ['created_at', 'updated_at'];

    public function productCategory(){
        return $this->belongsTo('App\Categories','category_id');
    }

    public function promocode(){
        return $this->hasMany('App\Promocode');
    }

    public function profile(){
        return $this->hasMany('App\Purchases');
    }

    public function review(){
        return $this->hasMany('App\Reviews');
    }

    public function basket(){
        return $this->hasMany('App\Basket');
    }

}
