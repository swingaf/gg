<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Settings extends Model
{
    protected $table = 'settings';

	protected $fillable = ['domain', 'sitename', 'title', 'desc', 'keys', 'best_1', 'best_2', 'best_3', 'best_1_sale', 'best_2_sale', 'best_3_sale', 'facebook_link', 'youtube_link', 'instagram_link', 'vk_link', 'vk_support_link', 'min_dep', 'max_dep', 'services_category', 'order_id', 'mrh_ID', 'mrh_secret1', 'mrh_secret2', 'fk_api', 'fk_wallet'];

    protected $hidden = ['created_at', 'updated_at'];

}
