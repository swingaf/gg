<?php namespace App;

use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;

class Reviews extends Model
{

    protected $table = 'reviews';

    protected $fillable = ['user_id', 'item_id', 'text', 'star', 'status'];

    protected $hidden = ['updated_at', 'created_at'];

    public function reviewProduct(){
        return $this->belongsTo('App\Products','item_id');
    }

    public function reviewOwner(){
        return $this->belongsTo('App\User','user_id');
    }
}
