<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    use Notifiable;

    protected $table = 'users';

    protected $fillable = ['user_id', 'username', 'avatar', 'balance', 'reg_ip', 'last_ip', 'ban', 'ban_reason', 'ref'];

    public function review(){
        return $this->hasMany('App\Reviews');
    }

    public function purchases(){
        return $this->hasMany('App\Purchases');
    }

    public function deposit(){
        return $this->hasMany('App\Payments');
    }
}
