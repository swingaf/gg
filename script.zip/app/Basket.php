<?php namespace App;

use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;

class Basket extends Model
{

    protected $table = 'basket';

    protected $fillable = ['user_id', 'product_id', 'status'];

    protected $hidden = ['created_at', 'updated_at'];

    public function basketProduct(){
        return $this->belongsTo('App\Products','product_id');
    }

}
