<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Session;
use App\User;
use App\News;
use App\Faq;
use App\Basket;
use App\Reviews;
use App\Products;
use App\Purchases;
use App\Categories;
use App\Promocode;
use App\PromocodeLog;
use Carbon\Carbon;

class MainController extends Controller
{

    public function index()
    {
      $purchases = Purchases::where('status', '!=' ,0)->orderBy('id', 'desc')->limit(6)->get();
      $top = Products::where('status', 1)->orderBy('purchases', 'desc')->limit(3)->get();

      return view('pages.index', compact('purchases', 'top'));
    }

    public function catalog()
    {
      $products = Products::where('status', 1)->get();
      $categories = Categories::where('status', 1)->get();
      $purchases = Purchases::where('status', '!=' ,0)->orderBy('id', 'desc')->limit(6)->get();
      $top = Products::where('status', 1)->orderBy('purchases', 'desc')->limit(6)->get();

      return view('pages.catalog', compact('products', 'categories', 'purchases', 'top'));
    }

    public function category($id)
    {
      $products = Products::where('status', 1)->where('category_id', $id)->get();
      $categories = Categories::where('status', 1)->get();
      $purchases = Purchases::where('status', '!=' ,0)->orderBy('id', 'desc')->limit(6)->get();
      $top = Products::orderBy('purchases', 'desc')->limit(6)->get();

      return view('pages.catalog', compact('products', 'categories', 'purchases', 'top'));
    }

    public function faq()
    {
      $faq = Faq::where('status', 1)->get();

      return view('pages.faq', compact('faq'));
    }

    public function garant()
    {

      return view('pages.garant');
    }

    public function news()
    {
      $news = News::where('status', 1)->orderBy('id', 'desc')->get();

      return view('pages.news', compact('news'));
    }

    public function profile()
    {
      $purchases = Purchases::where('status', '!=' , 0)->where('user_id', $this->user->id)->orderBy('id', 'desc')->get();
      return view('pages.profile', compact('purchases'));
    }

    public function reviews()
    {
      $reviews = Reviews::where('status', 1)->orderBy('id', 'desc')->get();
      $products = Products::where('status', 1)->get();

      return view('pages.reviews', compact('reviews', 'products'));
    }

    public function services()
    {
      $products = Products::where(['status' => 1, 'category_id' => $this->settings->services_category])->get();
      return view('pages.services', compact('products'));
    }

    public function product($id)
    {
      $product = Products::where('id', $id)->first();
      $promocode = PromocodeLog::where(['product_id' => $id, 'user_id' => $this->user->id, 'status' => 0])->first();
      if($product && $product->status == 1)
      {
        if($promocode) {
          $newprice = $product->price-($product->price*$promocode->percent/100);
          return view('pages.product', compact('product', 'newprice'));
        }
      return view('pages.product', compact('product'));
      } else return redirect()->back()->with('error', 'Товар не существует');
    }

    public function addToBasket($id)
    {
      $productinbasket = Basket::where(['product_id' => $id, 'user_id' => $this->user->id, 'status' => 1])->count();
      if($productinbasket == 0)
      {
        $basket = Basket::create([
          'user_id' => $this->user->id,
          'product_id' => $id
        ]);
      } else return redirect()->back()->with('error', 'Товар уже добавлен в корзину');
      return redirect()->back()->with('success', 'Товар успешно добавлен в корзину');
    }

    public function removeFromBasket($id)
    {
      $productinbasket = Basket::where(['product_id' => $id, 'user_id' => $this->user->id, 'status' => 1])->count();
      if($productinbasket == 1)
      {
        $basket = Basket::where(['product_id' => $id, 'user_id' => $this->user->id, 'status' => 1])->update(['status' => 0]);
      } else return redirect()->back()->with('error', 'Товар не найден в корзине');
      return redirect()->back()->with('success', 'Товар успешно удален из корзины');
    }

    public function promoActivate(Request $r) {
          $code = $r->get('code');

          if(!$code) return redirect()->back()->with('error', 'Вы не ввели промокод');

          $promocode = Promocode::where('code', $code)->first();

          if($promocode) {

              if($promocode->limit == 1 && $promocode->count_use <= 0) return redirect()->back()->with('error', 'Код больше не активен');

              if($promocode->limit == 1 && $promocode->count_use > 0)
              {
                  $promocode->count_use -= 1;
                  $promocode->save();
              }

              PromocodeLog::insert([
                  'user_id' => $this->user->id,
                  'product_id' => $promocode->product_id,
                  'percent' => $promocode->percent,
                  'code' => $code,
                  'code_id' => $promocode->id
              ]);

              $product = Products::where('id', $promocode->product_id)->first();
              return redirect()->back()->with('success', 'Промокод успешно активирован для товара '.$product->title.'');
          } else return redirect()->back()->with('error', 'Промокод не найден');
      }

    public function ref(Request $r) {
      $code = $r->get('code');
      if(!$code) return redirect()->route('index')->with('error', 'Код не найден');
      Session::put('ref', $code);
      return redirect()->route('index');
    }

    public function postReview(Request $r) {
      $review = $r->get('review');
      $star = $r->get('star');
      $script = $r->get('script');
      if(!$review) return redirect()->back()->with('error', 'Вы не написали отзыв');
      if(!$star) return redirect()->back()->with('error', 'Оценка для отзыва не поставлена');
      if(!$script) return redirect()->back()->with('error', 'Скрипт не выбран');
      $status = 0;
      if($this->user->is_admin == 1) $status = 1;
      Reviews::create([
        'user_id' => $this->user->id,
        'item_id' => $script,
        'text' => $review,
        'star' => $star,
        'status' => $status
      ]);
      if($status == 0) return redirect()->back()->with('success', 'Отзыв успешно отправлен на модерацию.');
      if($status == 1) return redirect()->back()->with('success', 'Отзыв успешно опубликован.');
    }

}
