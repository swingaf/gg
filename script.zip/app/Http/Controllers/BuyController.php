<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\News;
use App\Faq;
use App\Basket;
use App\Reviews;
use App\Settings;
use App\Products;
use App\Purchases;
use App\Payments;
use App\Promocode;
use App\PromocodeLog;
use App\Categories;
use Carbon\Carbon;

class BuyController extends Controller
{

  public function success() {
    return redirect()->route('index')->with('success', 'Ваш баланс успешно пополнен!');
  }

  public function fail() {
    return redirect()->route('index')->with('error', 'Ошибка при пополнении баланса!');
  }


  // Статусы:
  // 0 - заказ создан
  // 1 - заказ оплачен
  // 2 - заказ обработан

  public function buyProduct($id)
  {
    $product = Products::where('id', $id)->first();
    if($product)
    {
      if($product->status == 1)
      {
        $promocode = PromocodeLog::where(['product_id' => $product->id, 'user_id' => $this->user->id, 'status' => 0,])->first();
        if($promocode) $price = $product->price-($product->price*$promocode->percent/100); else $price = $product->price;
        if($promocode) $sale = $promocode->percent; else $sale = 0;
        if($promocode) {
          PromocodeLog::where('id', $promocode->id)->update(['status' => 1]);
        }
        if($this->user->balance >= $price)
        {
          $secret = bin2hex(random_bytes(16));
          Purchases::create([
            'product_id' => $product->id,
            'user_id' => $this->user->id,
            'price' => $price,
            'sale' => $sale,
            'secret' => $secret,
            'status' => 0
          ]);

          $purchase = Purchases::where(['product_id' => $product->id, 'user_id' => $this->user->id, 'status' => 0])->orderBy('created_at', 'desc')->first();

          if($purchase)
          {
            User::where('id', $this->user->id)->update([
              'balance' => $this->user->balance-$price
            ]);

            Purchases::where('id', $purchase->id)->update([
              'status' => 1
            ]);

            Products::where('id', $product->id)->update([
              'purchases' => $product->purchases
            ]);

            if(Basket::where(['user_id' => $this->user->id, 'status' => 1, 'product_id' => $product->id])->first())
            {
              Basket::where(['user_id' => $this->user->id, 'status' => 1, 'product_id' => $product->id])->update(['status' => 2]);
            }

            return redirect()->route('profile')->with('success', 'Вы успешно купили товар. Ваш номер заказа: '. $purchase->id .'');
          } else return redirect()->back()->with('error', 'Произошла ошибка при создании заказа!');
        } else return redirect()->back()->with('error', 'У вас недостаточно средств на балансе!');
      } else return redirect()->route('catalog')->with('error', 'Товар не активен!');
    } else return redirect()->route('catalog')->with('error', 'Товар не найден!');

  return redirect()->route('catalog')->with('error', 'Неизвестная ошибка!');
  }


  public function buyFromBasket()
  {
    $basket = Basket::where(['user_id' => $this->user->id, 'status' => 1])->get();

    foreach($basket as $buyproduct)
    {
        $this->buyProduct($buyproduct->product_id);
    }
    return redirect()->back();
  }

  public function pay(Request $r) {
      $sum = $r->get('num');
      if(!$sum) return redirect()->back()->with('error', 'Вы не ввели сумму депозита');
      if($sum <= $this->settings->min_dep) return redirect()->back()->with('error', 'Минимальная сумма для пополнения: '.$this->settings->min_dep.' рублей');
      if($sum >= $this->settings->max_dep) return redirect()->back()->with('error', 'Максимальная сумма для пополнения: '.$this->settings->max_dep.' рублей');

        Settings::where('id', 1)->update([
            'order_id' => $this->settings->order_id+1
        ]);

      return Redirect('https://www.free-kassa.ru/merchant/cash.php?m='.$this->settings->mrh_ID.'&oa='.$r->get('num').'&o='.$this->settings->order_id.'&us_uid='.$this->user->user_id.'&s='.md5($this->settings->mrh_ID.':'.$sum.':'.$this->settings->mrh_secret1.':'.$this->settings->order_id));

    }

    public function result(Request $r) {
          $ip = false;
          if(isset($_SERVER['HTTP_X_REAL_IP'])) {
              $ip = $this->getIp($_SERVER['HTTP_X_REAL_IP']);
          } else {
              $ip = $this->getIp($_SERVER['REMOTE_ADDR']);
          }
          if(!$ip) return redirect()->route('index')->with('error', 'Ошибка при проверке IP free-kassa!');

  		$order = $this->chechOrder($r->get('MERCHANT_ORDER_ID'), $r->get('AMOUNT'));
  		if($order['type'] == 'error') return ['msg' => $order['msg'], 'type' => 'error'];

  		/*CREATE PAY*/
          $pay = [
              'secret' => md5($this->settings->mrh_ID . ":" . $r->get('AMOUNT') . ":" . $this->settings->mrh_secret1 . ":" . $this->settings->order_id),
              'merchant_id' => $this->settings->mrh_ID,
              'order_id' => $r->get('MERCHANT_ORDER_ID'),
              'sum' => $r->get('AMOUNT'),
              'user_id' => $r->get('us_uid'),
              'status' => 0
          ];
          Payments::insert($pay);

          $user = User::where('user_id', $r->get('us_uid'))->first();
          if(!$user) return ['msg' => 'User not found!', 'type' => 'error'];

  		/* ADD Balance from user and partner */
          $sum = floor($r->get('AMOUNT'));
          User::where('user_id', $user->user_id)->update([
              'balance' => $user->balance+$sum
          ]);


                    if($user->ref)
                    {
                        $tid = str_replace('7offers_', '', $user->ref);
                        $payment_id = $r->get('MERCHANT_ORDER_ID');
                        $amount = $r->get('AMOUNT');
                        if($amount >= 3000) {
                        return redirect('https://pixel.7offers.ru/6087/4987/pixel.xml?id='.$payment_id.'&tid='.$tid.'&price='.$amount.'');
                      } elseif($amount >= 500) return redirect('https://pixel.7offers.ru/6087/4986/pixel.xml?id='.$payment_id.'&tid='.$tid.'');
                    }
          /*REDIRECT*/

          Payments::where('order_id', $r->get('MERCHANT_ORDER_ID'))->update([
              'status' => 1
          ]);

          /* SUCCESS REDIRECT */
          return ['msg' => 'Your order #'.$r->get('MERCHANT_ORDER_ID').' has been paid successfully!', 'type' => 'success'];
  	}

  	private function chechOrder($id, $sum) {
  		$merch = Payments::where('order_id', $id)->first();
  		if(!$merch) return ['msg' => 'Order checked!', 'type' => 'success'];
  		if($sum != $merch->sum) return ['msg' => 'You paid another order!', 'type' => 'error'];
  		if($merch->order_id == $id && $merch->status == 1) return ['msg' => 'Order alredy paid!', 'type' => 'error'];

  		return ['msg' => 'Order checked!', 'type' => 'success'];
  	}

      /* CHECK FREE KASSA IP */
      function getIp($ip) {
          $list = ['136.243.38.147', '136.243.38.149', '136.243.38.150', '136.243.38.151', '136.243.38.189', '136.243.38.108'];
          for($i = 0; $i < count($list); $i++) {
              if($list[$i] == $ip) return true;
          }
          return false;
      }

}
