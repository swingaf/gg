<?php

namespace App\Http\Controllers;

use \Yajra\Datatables\Datatables;
use Illuminate\Http\Request;
use App\News;
use App\User;
use App\Faq;
use App\Basket;
use App\Reviews;
use App\Promocode;
use App\PromocodeLog;
use App\Products;
use App\Purchases;
use App\Payments;
use App\SuccessPay;
use App\Categories;
use App\Settings;
use Carbon\Carbon;

class AdminController extends Controller
{

    public function index()
    {
      $pay_today = Payments::where('updated_at', '>=', Carbon::today())->where('status', 1)->sum('sum');
  		$pay_week = Payments::where('updated_at', '>=', Carbon::now()->subDays(7))->where('status', 1)->sum('sum');
  		$pay_month = Payments::where('updated_at', '>=', Carbon::now()->subDays(30))->where('status', 1)->sum('sum');
  		$pay_all = Payments::where('status', 1)->sum('sum');

      $deposits = Payments::where('status', 1)->orderBy('created_at', 'desc')->get();
      $purchases = Purchases::where('status', '!=', 0)->orderBy('created_at', 'desc')->get();
      $usersCount = User::count();
      $payed = Purchases::where('status', 2)->count();
      $reviews = Reviews::where('status', 0)->count();
      $newusers = User::orderBy('created_at', 'desc')->get();
      $earned = Purchases::sum('price');
      return view('admin.index', compact('pay_today', 'pay_week', 'pay_month', 'pay_all', 'deposits', 'usersCount', 'newusers', 'earned', 'payed', 'reviews', 'purchases'));
    }

    public function users()
    {

      return view('admin.users');
    }

    public function promo()
    {
      $promocodes = Promocode::all();
      $products = Products::all();
      return view('admin.promo', compact('promocodes', 'products'));
    }


    public function products()
    {
      $products = Products::all();
      $categories = Categories::all();
      return view('admin.products', compact('products', 'categories'));
    }

    public function settings()
    {
      $products = Products::where('status', 1)->get();
      $categories = Categories::all();
      return view('admin.settings', compact('products', 'categories'));
    }

    public function categories()
    {
      $categories = Categories::all();
      return view('admin.categories', compact('categories'));
    }

    public function reviews()
    {
      $reviews = Reviews::all();
      return view('admin.reviews', compact('reviews'));
    }

    public function news()
    {
      $news = News::all();
      return view('admin.news', compact('news'));
    }

    public function category($id)
    {
      $category = Categories::where('id', $id)->first();
      $productsincategory = Products::where('category_id', $id)->count();
      $productsbuyincategory = Products::where('category_id', $id)->sum('purchases');
      $products = Products::where('category_id', $id)->get();
      return view('admin.category', compact('category', 'productsincategory', 'productsbuyincategory', 'products'));
    }



    public function user($id) {
        $user = User::where('id', $id)->first();
        $pay = Payments::where('user_id', $user->id)->where('status', 1)->sum('sum');
        $purchases = Purchases::where('user_id', $user->id)->get();

        return view('admin.user', compact('user', 'pay', 'purchases'));
    }

    public function product($id) {
        $product = Products::where('id', $id)->first();
        $categories = Categories::where('status', 1)->get();
        $purchasescount = Purchases::where('product_id', $id)->where('status', '!=' , 0)->count();
        $purchasessum = Purchases::where('product_id', $id)->where('status', '!=' , 0)->sum('price');
        $purchases = Purchases::where('product_id', $id)->get();

        return view('admin.product', compact('product', 'categories', 'purchasescount', 'purchasessum', 'purchases'));
    }

    // CATEGORY

    public function categoryCreate(Request $r) {
        $name = $r->get('name');
        $status = $r->get('status');
        if(!$name) return redirect()->route('admin.categories')->with('error', 'Категория с таким названием уже существует!');

        Categories::create([
            'name' => $name,
            'status' => $status,
        ]);

        return redirect()->route('admin.categories')->with('success', 'Категория создана!');
    }


        public function categorySave(Request $r) {
            if($r->get('id') == null) return redirect()->route('admin.categories')->with('error', 'Не удалось найти категорию с таким ID!');

            Categories::where('id', $r->get('id'))->update([
                'name' => $r->get('name'),
            ]);

            return redirect()->route('admin.categories')->with('success', 'Категория сохранена!');
        }

    // END CATEGORY

    // NEWS

    public function newsCreate(Request $r) {
        $title = $r->get('title');
        $description = $r->get('description');
        $image = $r->get('image');
        if(!$title) return redirect()->route('admin.news')->with('error', 'Поле "Заголовок" не может быть пустым!');
        if(!$description) return redirect()->route('admin.news')->with('error', 'Поле "Текст" не может быть пустым!');
        if(!$image) return redirect()->route('admin.news')->with('error', 'Поле "Картинка" не может быть пустым!');

        News::create([
            'title' => $title,
            'description' => $description,
            'image' => $image,
        ]);

        return redirect()->route('admin.news')->with('success', 'Новость создана!');
    }

    public function newsSave(Request $r) {
        $id = $r->get('id');
        $title = $r->get('title');
        $description = $r->get('description');
        $image = $r->get('image');
        if(!$id) return redirect()->route('admin.news')->with('error', 'Не удалось найти данный ID!');
        if(!$title) return redirect()->route('admin.news')->with('error', 'Поле "Заголовок" не может быть пустым!');
        if(!$description) return redirect()->route('admin.news')->with('error', 'Поле "Текст" не может быть пустым!');
        if(!$image) return redirect()->route('admin.news')->with('error', 'Поле "Картинка" не может быть пустым!');

        News::where('id', $id)->update([
          'title' => $title,
          'description' => $description,
          'image' => $image,
        ]);

        return redirect()->route('admin.news')->with('success', 'Новость обновлена!');
    }

    // END NEWS

    // PROMO

    public function promoCreate(Request $r) {
        $code = $r->get('code');
        $type = $r->get('type');
        $limit = $r->get('limit');
        $percent = $r->get('percent');
        $count_use = $r->get('count_use');
        $product_id = $r->get('product_id');
        $have = Promocode::where('code', $code)->first();
        if(!$product_id) return redirect()->route('admin.promo')->with('error', 'Промокод должен быть привязан к товару!');
        if(!$code) return redirect()->route('admin.promo')->with('error', 'Поле "Код" не может быть пустым!');
        if(!$percent) return redirect()->route('admin.promo')->with('error', 'Поле "Процент" не может быть пустым!');
        if(!$count_use) return redirect()->route('admin.promo')->with('error', 'Поле "Кол-во активаций" не может быть пустым!');
        if($have) return redirect()->route('admin.promo')->with('error', 'Такой код уже существует');

        Promocode::create([
            'code' => $code,
            'limit' => $limit,
            'percent' => $percent,
            'count_use' => $count_use,
            'product_id' => $product_id
        ]);

        return redirect()->route('admin.promo')->with('success', 'Промокод создан!');
    }

    public function promoSave(Request $r) {
        $id = $r->get('id');
        $code = $r->get('code');
        $type = $r->get('type');
        $limit = $r->get('limit');
        $product_id = $r->get('product_id');
        $percent = $r->get('percent');
        $count_use = $r->get('count_use');
        $have = Promocode::where('code', $code)->where('id', '!=', $id)->first();
        if(!$id) return redirect()->route('admin.promo')->with('error', 'Не удалось найти данный ID!');
        if(!$product_id) return redirect()->route('admin.promo')->with('error', 'Промокод должен быть привязан к товару!');
        if(!$code) return redirect()->route('admin.promo')->with('error', 'Поле "Код" не может быть пустым!');
        if(!$percent) return redirect()->route('admin.promo')->with('error', 'Поле "Процент" не может быть пустым!');
        if(!$count_use) $count_use = 0;
        if($have) return redirect()->route('admin.promo')->with('error', 'Такой код уже существует');

        Promocode::where('id', $id)->update([
            'code' => $code,
            'limit' => $limit,
            'percent' => $percent,
            'count_use' => $count_use,
            'product_id' => $product_id
        ]);

        return redirect()->route('admin.promo')->with('success', 'Промокод обновлен!');
    }

    public function promoDelete($id) {
        if(!$id) return redirect()->route('admin.promo')->with('error', 'Нет такого промокода!');
        Promocode::where('id', $id)->delete();

        return redirect()->route('admin.promo')->with('success', 'Промокод удален!');
    }

    // PROMO END

    public function usersAjax() {
        return datatables(User::query())->toJson();
    }

    public function productCreate(Request $r) {
      $title = $r->get('title');
      $description = $r->get('description');
      $image = $r->get('image');
      $price = $r->get('price');
      $category_id = $r->get('category_id');

      if(!$category_id) return redirect()->route('admin.products')->with('error', 'Товар должен быть привязан к категории!');
      if(!$title) return redirect()->route('admin.products')->with('error', 'Поле "Название" не может быть пустым!');
      if(!$image) return redirect()->route('admin.products')->with('error', 'Поле "Картинка" не может быть пустым!');
      if(!$price) return redirect()->route('admin.products')->with('error', 'Поле "Цена" не может быть пустым!');
      if(!$description) return redirect()->route('admin.products')->with('error', 'Поле "Описание" не может быть пустым!');

      Products::create([
          'title' => $title,
          'description' => $description,
          'image' => $image,
          'price' => $price,
          'category_id' => $category_id,
          'download_link' => $r->get('download_link'),
          'download_pass' => $r->get('download_pass'),
      ]);

      return redirect()->route('admin.products')->with('success', 'Товар создан!');
    }

    public function settingsSave(Request $r) {
      Settings::first()->update([
          'domain' => $r->get('domain'),
          'sitename' => $r->get('sitename'),
          'title' => $r->get('title'),
          'desc' => $r->get('desc'),
          'keys' => $r->get('keys'),
          'best_1' => $r->get('best_1'),
          'best_2' => $r->get('best_2'),
          'best_3' => $r->get('best_3'),
          'best_1_sale' => $r->get('best_1_sale'),
          'best_2_sale' => $r->get('best_2_sale'),
          'best_3_sale' => $r->get('best_3_sale'),
          'min_dep' => $r->get('min_dep'),
          'max_dep' => $r->get('max_dep'),
          'vk_link' => $r->get('vk_link'),
          'vk_support_link' => $r->get('vk_support_link'),
          'instagram_link' => $r->get('instagram_link'),
          'youtube_link' => $r->get('youtube_link'),
          'facebook_link' => $r->get('facebook_link'),
          'mrh_ID' => $r->get('mrh_ID'),
          'mrh_secret1' => $r->get('mrh_secret1'),
          'mrh_secret2' => $r->get('mrh_secret2'),
          'fk_api' => $r->get('fk_api'),
          'fk_wallet' => $r->get('fk_wallet'),
          'services_category' => $r->get('services_category'),
      ]);


        return redirect()->route('admin.settings')->with('success', 'Настройки сохранены!');
    }


    public function productSave(Request $r) {
      if($r->get('id') == null) return back()->with('error', 'Не удалось найти продукт с таким ID!');
      if($r->get('title') == null) return back()->with('error', 'Поле "Название" не может быть пустым!');
      if($r->get('price') == null) return back()->with('error', 'Поле "Цена" не может быть пустым!');
      if($r->get('description') == null) return back()->with('error', 'Поле "Описание" не может быть пустым!');
      if($r->get('image') == null) return back()->with('error', 'Поле "Картинка" не может быть пустым!');

      Products::where('id', $r->get('id'))->update([
          'title' => $r->get('title'),
          'price' => $r->get('price'),
          'description' => $r->get('description'),
          'image' => $r->get('image'),
          'category_id' => $r->get('category'),
          'download_link' => $r->get('download_link'),
          'download_pass' => $r->get('download_pass'),
      ]);

        return redirect()->route('admin.products')->with('success', 'Продукт сохранен!');
    }



    public function userSave(Request $r) {
        $admin = 0;
        if($r->get('id') == null) return back()->with('error', 'Не удалось найти пользователя с таким ID!');
        if($r->get('balance') == null) return back()->with('error', 'Поле "Баланс" не может быть пустым!');

        User::where('id', $r->get('id'))->update([
            'balance' => $r->get('balance'),
            'is_admin' => $r->get('priv'),
            'ban' => $r->get('ban'),
            'ban_reason' => $r->get('ban_reason'),
        ]);

        return back()->with('success', 'Пользователь сохранен!');
    }

    public function productStatus($product, $status) {

      Products::where('id', $product)->update([
        'status' => $status
      ]);

      if($status == 0) Basket::where(['product_id' => $product, 'status' => 1])->update(['status' => 0]);

        return back()->with('success', 'Товар сохранен!');
    }


    public function reviewStatus($review, $status) {

      Reviews::where('id', $review)->update([
        'status' => $status
      ]);

        return back()->with('success', 'Отзыв сохранен!');
    }

    public function newsStatus($news, $status) {

      News::where('id', $news)->update([
        'status' => $status
      ]);

        return back()->with('success', 'Новость сохранена!');
    }

    public function categoryStatus($category, $status) {

      Categories::where('id', $category)->update([
        'status' => $status
      ]);

        return back()->with('success', 'Категория сохранена!');
    }

}
