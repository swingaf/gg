<?php

namespace App\Http\Controllers;

use DB;
use Auth;
use App\User;
use App\Categories;
use App\Products;
use App\Promocode;
use App\PromocodeLog;
use App\Basket;
use App\Settings;
use Carbon\Carbon;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    protected $user;

    public function __construct()
    {
        Carbon::setLocale('ru');

        $this->middleware(function ($request, $next) {

            $this->user = Auth::user();

            if(Auth::user())
            {
            $basket = Basket::where(['user_id' => $this->user->id, 'status' => 1])->get();
        		$data = [];
        		foreach($basket as $info) {
        			$product = Products::where('id', $info->product_id)->first();
              $category = Categories::where('id', $product->category_id)->first();
              $promocode = PromocodeLog::where(['product_id' => $product->id, 'user_id' => $this->user->id, 'status' => 0,])->first();
                if($promocode) $newprice = $product->price-($product->price*$promocode->percent/100); else $newprice = $product->price;
                if($promocode) $sale = $promocode->percent; else $sale = 0;
        			$data[] = [
        				'id' => $info->id,
                'product_status' => $product->status,
        				'product_id' => $product->id,
        				'product_title' => $product->title,
        				'product_image' => $product->image,
        				'product_price' => $product->price,
                'product_newprice' => $newprice,
                'product_sale' => $sale,
                'category_name' => $category->name,
                'category_id' => $category->id,
        			];
            view()->share(['basket' => $basket, 'data' => $data]);
        		}
            $basketcount = Basket::where(['user_id' => $this->user->id, 'status' => 1])->count();
            view()->share(['u' => $this->user, 'basketcount' => $basketcount]);
            }
            return $next($request);
        });

        $random = Products::where('status', 1)->inRandomOrder()->limit(3)->get();
        $this->settings = Settings::first();
        view()->share(['settings' => $this->settings, 'random' => $random]);

        $best_1 = Products::where('id', $this->settings->best_1)->first();
        $best_2 = Products::where('id', $this->settings->best_2)->first();
        $best_3 = Products::where('id', $this->settings->best_3)->first();
        view()->share(['best_1' => $best_1, 'best_2' => $best_2, 'best_3' => $best_3]);


        $this->pdo = DB::connection()->getPdo();
        $this->pdo->exec('SET TRANSACTION ISOLATION LEVEL READ COMMITTED');


	}
}
