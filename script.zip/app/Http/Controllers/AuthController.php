<?php namespace App\Http\Controllers;

use Auth;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Cookie;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Session;
use Laravel\Socialite\Facades\Socialite;

class AuthController extends Controller
{

    public function login()
    {
        $provider = 'vkontakte';
        return Socialite::driver($provider)->redirect();
    }

    public function callback()
    {
    $provider = 'vkontakte';
		if (Input::get('error') == 'access_denied') {
            return redirect('/');
        }
        $user = json_decode(json_encode(Socialite::driver($provider)->stateless()->user()));
        if(isset($user->returnUrl)) return redirect('/');
        $user = $user->user;
        $user = $this->createOrGetUser($user, $provider);
        Auth::login($user, true);
        return redirect('/');
    }

    public function createOrGetUser($user, $provider)
    {
        if ($provider == 'vkontakte') {
            $u = User::where('user_id', $user->id)->first();
            if ($u) {
                $username = $user->first_name.' '.$user->last_name;
                User::where('user_id', $user->id)->update([
                    'username' => $username,
                    'avatar' => $user->photo_max,
                    'last_ip' => request()->ip()
                ]);
                $user = $u;
            } else {
                $username = $user->first_name.' '.$user->last_name;
                $user = User::create([
                    'user_id' => $user->id,
                    'username' => $username,
                    'avatar' => $user->photo_max,
                    'reg_ip' => request()->ip(),
                    'last_ip' => request()->ip(),
                ]);

                if(Session::get('ref')) {
                User::where('id', $user->id)->update([
                  'ref' => Session::get('ref'),
                ]);
                }
            }
        }
        return $user;
    }

    public function logout()
    {
		Cache::flush();
    Auth::logout();
		Session::flush();
    return redirect('/');
    }
}
