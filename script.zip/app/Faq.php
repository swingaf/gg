<?php namespace App;

use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;

class Faq extends Model
{

    protected $table = 'faq';

    protected $fillable = ['title', 'text', 'status'];

    protected $hidden = ['updated_at', 'created_at'];
}
