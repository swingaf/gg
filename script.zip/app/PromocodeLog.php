<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PromocodeLog extends Model
{
    protected $table = 'promocode_log';

	protected $fillable = ['user_id', 'product_id', 'percent', 'status'];

    protected $hidden = ['created_at', 'updated_at'];

}
