<?php namespace App;

use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;

class Categories extends Model
{

    protected $table = 'categories';

    protected $fillable = ['name', 'status'];

    protected $hidden = ['created_at', 'updated_at'];

    public function catalog(){
        return $this->hasMany('App\Products');
    }
}
