@extends('admin')

@section('content')
<div class="kt-subheader kt-grid__item" id="kt_subheader">
	<div class="kt-subheader__main">
		<h3 class="kt-subheader__title">Редактирование категории</h3>
	</div>
</div>

<div class="kt-content  kt-grid__item kt-grid__item--fluid" id="kt_content">
	<div class="row">
		<div class="col-xl-4">
			<div class="kt-portlet kt-portlet--fit kt-portlet--head-lg kt-portlet--head-overlay">
				<div class="kt-portlet__head kt-portlet__space-x">
					<div class="kt-portlet__head-label" style="width: 100%;">
						<h3 class="kt-portlet__head-title text-center" style="width: 100%;">
							{{ $category->name }}
						</h3>
					</div>
				</div>
				<div class="kt-portlet__body">
					<div class="kt-widget28">
					<br>
					<br>
						<div class="kt-widget28__wrapper kt-portlet__space-x">
							<div class="tab-content">
								<div id="menu11" class="tab-pane active">
									<div class="kt-widget28__tab-items">
										<div class="kt-widget12">
											<div class="kt-widget12__content">
												<div class="kt-widget12__item">
													<div class="kt-widget12__info text-center">
														<span class="kt-widget12__desc">Товаров в категории</span>
														<span class="kt-widget12__value">{{ $productsincategory }}</span>
													</div>
													<div class="kt-widget12__info text-center">
														<span class="kt-widget12__desc">Товаров куплено в категории</span>
														<span class="kt-widget12__value">{{ $productsbuyincategory }}</span>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-xl-8">
			<div class="kt-portlet">
				<div class="kt-portlet__head">
					<div class="kt-portlet__head-label">
						<h3 class="kt-portlet__head-title">
							Информация о категории
						</h3>
					</div>
				</div>
				<!--begin::Form-->
				<form class="kt-form" method="post" action="/admin/category/save">
					<div class="kt-portlet__body">
						<input name="id" value="{{$category->id}}" type="hidden">
						<div class="form-group row">
							<div class="col-lg-12">
								<label>Название:</label>
								<input name="name" type="text" class="form-control" value="{{ $category->name }}">
							</div>
						</div>
					</div>
					<div class="kt-portlet__foot kt-portlet__foot--solid">
						<div class="kt-form__actions">
							<div class="row">
								<div class="col-12">
									<button type="submit" class="btn btn-brand">Сохранить</button>
								</div>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
	<div class="kt-content kt-grid__item kt-grid__item--fluid" id="kt_content">
		<div class="kt-portlet kt-portlet--mobile">
			<div class="kt-portlet__head kt-portlet__head--lg">
				<div class="kt-portlet__head-label">
					<span class="kt-portlet__head-icon">
						<span class="kt-menu__link-icon">
									<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1" class="kt-svg-icon">
													<g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
															<rect id="bound" x="0" y="0" width="24" height="24"></rect>
															<path d="M8,3 L8,3.5 C8,4.32842712 8.67157288,5 9.5,5 L14.5,5 C15.3284271,5 16,4.32842712 16,3.5 L16,3 L18,3 C19.1045695,3 20,3.8954305 20,5 L20,21 C20,22.1045695 19.1045695,23 18,23 L6,23 C4.8954305,23 4,22.1045695 4,21 L4,5 C4,3.8954305 4.8954305,3 6,3 L8,3 Z" id="Combined-Shape" fill="#000000" opacity="0.3"></path>
															<path d="M11,2 C11,1.44771525 11.4477153,1 12,1 C12.5522847,1 13,1.44771525 13,2 L14.5,2 C14.7761424,2 15,2.22385763 15,2.5 L15,3.5 C15,3.77614237 14.7761424,4 14.5,4 L9.5,4 C9.22385763,4 9,3.77614237 9,3.5 L9,2.5 C9,2.22385763 9.22385763,2 9.5,2 L11,2 Z" id="Combined-Shape" fill="#000000"></path>
															<rect id="Rectangle-152" fill="#000000" opacity="0.3" x="10" y="9" width="7" height="2" rx="1"></rect>
															<rect id="Rectangle-152-Copy-2" fill="#000000" opacity="0.3" x="7" y="9" width="2" height="2" rx="1"></rect>
															<rect id="Rectangle-152-Copy-3" fill="#000000" opacity="0.3" x="7" y="13" width="2" height="2" rx="1"></rect>
															<rect id="Rectangle-152-Copy" fill="#000000" opacity="0.3" x="10" y="13" width="7" height="2" rx="1"></rect>
															<rect id="Rectangle-152-Copy-5" fill="#000000" opacity="0.3" x="7" y="17" width="2" height="2" rx="1"></rect>
															<rect id="Rectangle-152-Copy-4" fill="#000000" opacity="0.3" x="10" y="17" width="7" height="2" rx="1"></rect>
													</g>
										</svg>
						</span>
					</span>
					<h3 class="kt-portlet__head-title">
						Товары в категории
					</h3>
				</div>
			</div>
			<div class="kt-portlet__body">
				<br>
				<table class="table table-striped- table-bordered table-hover table-checkable">
					<thead>
						<tr>
							<th>ID</th>
							<th>Название</th>
							<th>Активна?</th>
							<th>Действия</th>
						</tr>
					</thead>
					<tbody>
					@foreach($products as $product)
					<tr>
						<td>{{ $product->id }}</td>
						<td>{{ $product->title }}</td>
						<td>
							@if($product->status == 1) <span class="kt-badge kt-badge--success kt-badge--inline kt-badge--pill">Да</span> @else <span class="kt-badge kt-badge--danger kt-badge--inline kt-badge--pill">Нет</span> @endif
						</td>
						<td><a href="/admin/product/{{ $product->id }}" class="btn btn-sm btn-clean btn-icon btn-icon-md" title="Редактировать"><i class="la la-edit"></i></a> @if($product->status == 1) <a href="/admin/product/status/{{ $product->id }}/0" class="btn btn-sm btn-clean btn-icon btn-icon-md" title="Скрывать категорию"><i class="la la-eye-slash"></i></a> @elseif($product->status == 0) <a href="/admin/product/status/{{ $product->id }}/1" class="btn btn-sm btn-clean btn-icon btn-icon-md" title="Показывать товар"><i class="la la-eye"></i></a> @endif</td>
					</tr>
					@endforeach
					</tbody>
				</table>

			</div>
		</div>
	</div>
</div>
@endsection
