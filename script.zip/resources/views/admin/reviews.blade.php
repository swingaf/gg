@extends('admin')

@section('content')
<script src="/dash/js/dtables.js" type="text/javascript"></script>
<div class="kt-subheader kt-grid__item" id="kt_subheader">
	<div class="kt-subheader__main">
		<h3 class="kt-subheader__title">Отзывы</h3>
	</div>
</div>

<div class="kt-content kt-grid__item kt-grid__item--fluid" id="kt_content">
	<div class="kt-portlet kt-portlet--mobile">
		<div class="kt-portlet__head kt-portlet__head--lg">
			<div class="kt-portlet__head-label">
				<span class="kt-portlet__head-icon">
					<i class="kt-font-brand flaticon2-menu-2"></i>
				</span>
				<h3 class="kt-portlet__head-title">
					Список отзывов
				</h3>
			</div>
		</div>
		<div class="kt-portlet__body">

			<!--begin: Datatable -->
			<table class="table table-striped- table-bordered table-hover table-checkable" id="dtable">
				<thead>
					<tr>
						<th>ID</th>
						<th>Пользователь</th>
						<th>Товар</th>
						<th>Текст</th>
						<th>Информация</th>
						<th>Дата</th>
						<th>Действия</th>
					</tr>
				</thead>
				<tbody>
				@foreach($reviews as $review)
				<tr>
					<td>{{ $review->id }}</td>
					<td><a href="/admin/product/{{ $review->reviewOwner->id }}">{{ $review->reviewOwner->username }}</a></td>
					<td><a href="/admin/product/{{ $review->reviewProduct->id }}">{{ $review->reviewProduct->title }}</td>
					<td>{{ $review->text }}</td>
					<td>
						@if($review->star == 0) <span class="kt-badge kt-badge--danger kt-badge--inline kt-badge--pill">Отрицательный</span> @elseif($review->star == 1) <span class="kt-badge kt-badge--success kt-badge--inline kt-badge--pill">Положительный</span> @endif
						@if($review->status == 0) <span class="kt-badge kt-badge--warning kt-badge--inline kt-badge--pill">На модерации</span> @elseif($review->status == 1) <span class="kt-badge kt-badge--success kt-badge--inline kt-badge--pill">Одобрен</span> @elseif($review->status == 2) <span class="kt-badge kt-badge--danger kt-badge--inline kt-badge--pill">Отклонен</span> @endif
					</td>
					<td>{{ $review->created_at->format('d.m.y h:m') }}</td>
					<td> @if($review->status == 0) <a href="/admin/review/status/{{ $review->id }}/1" class="btn btn-sm btn-clean btn-icon btn-icon-md" title="Одобрить отзыв"><i class="la la-check"></i></a> <a href="/admin/review/status/{{ $review->id }}/2" class="btn btn-sm btn-clean btn-icon btn-icon-md" title="Отклонить отзыв"><i class="la la-close"></i></a>
							 @elseif($review->status == 1) <a href="/admin/review/status/{{ $review->id }}/2" class="btn btn-sm btn-clean btn-icon btn-icon-md" title="Скрывать отзыв"><i class="la la-eye-slash"></i></a>
							 @elseif($review->status == 2) <a href="/admin/review/status/{{ $review->id }}/1" class="btn btn-sm btn-clean btn-icon btn-icon-md" title="Показывать отзыв"><i class="la la-eye"></i></a> @endif</td>
				</tr>
				@endforeach
				</tbody>
			</table>

			<!--end: Datatable -->
		</div>
	</div>
</div>
@endsection
