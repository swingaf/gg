@extends('admin')

@section('content')
<script type="text/javascript" src="/js/chart.min.js"></script>
<div class="kt-subheader kt-grid__item" id="kt_subheader">
	<div class="kt-subheader__main">
		<h3 class="kt-subheader__title">Статистика</h3>
	</div>
	<div class="kt-subheader__toolbar">

    </div>
</div>

<div class="kt-content  kt-grid__item kt-grid__item--fluid" id="kt_content">
	<div class="kt-portlet">
		<div class="kt-portlet__body  kt-portlet__body--fit">
			<div class="row row-no-padding row-col-separator-xl">

				<div class="col-md-12 col-lg-6 col-xl-3">
					<!--begin::Total Profit-->
					<div class="kt-widget24">
						<div class="kt-widget24__details">
							<div class="kt-widget24__info">
								<h4 class="kt-widget24__title">
									Пополнений на
								</h4>
								<span class="kt-widget24__desc">
									за сегодня
								</span>
							</div>

							<span class="kt-widget24__stats kt-font-success">
								{{ $pay_today }}<i class="la la-rub"></i>
							</span>
						</div>
					</div>
					<!--end::Total Profit-->
				</div>

				<div class="col-md-12 col-lg-6 col-xl-3">
					<!--begin::New Feedbacks-->
					<div class="kt-widget24">
						<div class="kt-widget24__details">
							<div class="kt-widget24__info">
								<h4 class="kt-widget24__title">
									Пополнений на
								</h4>
								<span class="kt-widget24__desc">
									за 7 дней
								</span>
							</div>

							<span class="kt-widget24__stats kt-font-success">
							   {{ $pay_week }}<i class="la la-rub"></i>
							</span>
						</div>
					</div>
					<!--end::New Feedbacks-->
				</div>

				<div class="col-md-12 col-lg-6 col-xl-3">
					<!--begin::New Orders-->
					<div class="kt-widget24">
						<div class="kt-widget24__details">
							<div class="kt-widget24__info">
								<h4 class="kt-widget24__title">
									Пополнений на
								</h4>
								<span class="kt-widget24__desc">
									за месяц
								</span>
							</div>

							<span class="kt-widget24__stats kt-font-success">
								{{ $pay_month }}<i class="la la-rub"></i>
							</span>
						</div>
					</div>
					<!--end::New Orders-->
				</div>

				<div class="col-md-12 col-lg-6 col-xl-3">
					<!--begin::New Users-->
					<div class="kt-widget24">
						<div class="kt-widget24__details">
							<div class="kt-widget24__info">
								<h4 class="kt-widget24__title">
									Пополнений на
								</h4>
								<span class="kt-widget24__desc">
									за все время
								</span>
							</div>

							<span class="kt-widget24__stats kt-font-success">
								{{ $pay_all }}<i class="la la-rub"></i>
							</span>
						</div>
					</div>
					<!--end::New Users-->
				</div>

			</div>
		</div>
	</div>
	<div class="kt-portlet">
		<div class="kt-portlet__body  kt-portlet__body--fit">
			<div class="row row-no-padding row-col-separator-xl">

				<div class="col-md-12 col-lg-6 col-xl-3">
					<!--begin::Total Profit-->
					<div class="kt-widget24">
						<div class="kt-widget24__details">
							<div class="kt-widget24__info">
								<h4 class="kt-widget24__title">
									Пользователей
								</h4>
								<span class="kt-widget24__desc">
									всего
								</span>
							</div>

							<span class="kt-widget24__stats kt-font-brand">
								{{ $usersCount }}<i class="la la-user"></i>
							</span>
						</div>
					</div>
					<!--end::Total Profit-->
				</div>

				<div class="col-md-12 col-lg-6 col-xl-3">
					<!--begin::New Orders-->
					<div class="kt-widget24">
						<div class="kt-widget24__details">
							<div class="kt-widget24__info">
								<h4 class="kt-widget24__title">
									Заработано
								</h4>
								<span class="kt-widget24__desc">
									общая сумма
								</span>
							</div>

							<span class="kt-widget24__stats kt-font-danger">
								{{ $earned }}<i class="la la-rub"></i>
							</span>
						</div>
					</div>
					<!--end::New Orders-->
				</div>


				<div class="col-md-12 col-lg-6 col-xl-3">
					<!--begin::New Orders-->
					<div class="kt-widget24">
						<div class="kt-widget24__details">
							<div class="kt-widget24__info">
								<h4 class="kt-widget24__title">
									Заказов оплачено
								</h4>
								<span class="kt-widget24__desc">
									в ожидании
								</span>
							</div>

							<span class="kt-widget24__stats kt-font-warning">
								{{ $payed }}<i class="la la-clock-o"></i>
							</span>
						</div>
					</div>
					<!--end::New Orders-->
				</div>

				<div class="col-md-12 col-lg-6 col-xl-3">
					<!--begin::New Orders-->
					<div class="kt-widget24">
						<div class="kt-widget24__details">
							<div class="kt-widget24__info">
								<h4 class="kt-widget24__title">
									Отзывов на модерации
								</h4>
								<span class="kt-widget24__desc">
									в ожидании
								</span>
							</div>

							<span class="kt-widget24__stats kt-font-@if($reviews > 0)warning @elseif($reviews == 0)success @endif">
								{{ $reviews }}@if($reviews > 0) <i class="la la-clock-o"> @elseif($reviews == 0) <i class="la la-check"> @endif</i>
							</span>
						</div>
					</div>
					<!--end::New Orders-->
				</div>

			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-xl-4">
			<div class="kt-portlet">
				<div class="kt-portlet__head">
					<div class="kt-portlet__head-label">
						<h3 class="kt-portlet__head-title">
							Последние пополнения
						</h3>
					</div>
				</div>
				<div class="kt-portlet__body">
					<div class="kt-widget3 kt-scroll" data-scroll="true" data-height="616">

						@foreach($deposits as $deposit)
						<div class="kt-widget3__item">
							<div class="kt-widget3__header">
								<div class="kt-widget3__user-img">
									<img class="kt-widget3__img" src="{{ $deposit->avatar }}" alt="">
								</div>
								<div class="kt-widget3__info">
									<a href="/admin/user/{{ $deposit->id }}" class="kt-widget3__username">
									{{ $deposit->username }}
									</a><br>
									<span class="kt-widget3__time">
									 {{ $deposit->last_ip }}
									</span>
								</div>
								<span class="kt-widget3__status kt-font-success">
									{{ $deposit->sum }} <i class="la la-rub"></i>
								</span>
							</div>
						</div>
						@endforeach

					</div>
				</div>
			</div>
		</div>
		<div class="col-xl-4">
			<div class="kt-portlet">
				<div class="kt-portlet__head">
					<div class="kt-portlet__head-label">
						<h3 class="kt-portlet__head-title">
							Последние покупки
						</h3>
					</div>
				</div>
				<div class="kt-portlet__body">
					<div class="kt-widget3 kt-scroll" data-scroll="true" data-height="616">

						@foreach($purchases as $purchase)
						<div class="kt-widget3__item">
							<div class="kt-widget3__header">
								<div class="kt-widget3__user-img">
									<img class="kt-widget3__img" src="{{ $purchase->owner->avatar }}" alt="">
								</div>
								<div class="kt-widget3__info">
									<a href="/admin/user/{{ $purchase->owner->id }}" class="kt-widget3__username">
								 {{ $purchase->owner->username }}
									</a>
									<br>
									<span class="kt-widget3__time">
										<a href="/admin/product/{{ $purchase->product->id }}">
										{{ $purchase->product->title }}
										</a>
									</span>
								</div>
								<span class="kt-widget3__status kt-font-success">
									{{ $purchase->price }}<i class="la la-rub"></i>
								</span>
							</div>
						</div>
						@endforeach

					</div>
				</div>
			</div>
		</div>
		<div class="col-xl-4">
			<div class="kt-portlet">
				<div class="kt-portlet__head">
					<div class="kt-portlet__head-label">
						<h3 class="kt-portlet__head-title">
							Новые пользователи
						</h3>
					</div>
				</div>
				<div class="kt-portlet__body">
					<div class="kt-widget3 kt-scroll" data-scroll="true" data-height="616">

						@foreach($newusers as $user)
						<div class="kt-widget3__item">
							<div class="kt-widget3__header">
								<div class="kt-widget3__user-img">
									<img class="kt-widget3__img" src="$pay['avatar']" alt="">
								</div>
								<div class="kt-widget3__info">
									<a href="/admin/user/{{ $user->id }}" class="kt-widget3__username">
									{{ $user->username }}
									</a><br>
									<span class="kt-widget3__time">

									</span>
								</div>
								<span class="kt-widget3__status kt-font-success">
								{{ $user->reg_ip }}
								</span>
							</div>
						</div>
						@endforeach
					</div>
				</div>
			</div>
		</div>
	</div>



</div>


@endsection
