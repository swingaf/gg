@extends('admin')

@section('content')
<script src="/dash/js/dtables.js" type="text/javascript"></script>
<div class="kt-subheader kt-grid__item" id="kt_subheader">
	<div class="kt-subheader__main">
		<h3 class="kt-subheader__title">Товары</h3>
	</div>
</div>

<div class="kt-content kt-grid__item kt-grid__item--fluid" id="kt_content">
	<div class="kt-portlet kt-portlet--mobile">
		<div class="kt-portlet__head kt-portlet__head--lg">
			<div class="kt-portlet__head-label">
				<span class="kt-portlet__head-icon">
					<i class="kt-font-brand flaticon2-menu-2"></i>
				</span>
				<h3 class="kt-portlet__head-title">
					Список товаров
				</h3>
			</div>
			<div class="kt-portlet__head-toolbar">
				<div class="kt-portlet__head-wrapper">
					<div class="kt-portlet__head-actions">
						<a data-toggle="modal" href="#new" class="btn btn-success btn-elevate btn-icon-sm">
							<i class="la la-plus"></i>
							Создать
						</a>
					</div>
				</div>
			</div>
		</div>
		<div class="kt-portlet__body">

			<!--begin: Datatable -->
			<table class="table table-striped- table-bordered table-hover table-checkable" id="dtable">
				<thead>
					<tr>
						<th>ID</th>
						<th>Название</th>
						<th>Категория</th>
						<th>Цена</th>
						<th>Кол-во покупок</th>
						<th>Активен?</th>
						<th>Действия</th>
					</tr>
				</thead>
				<tbody>
				@foreach($products as $product)
				<tr>
					<td>{{ $product->id }}</td>
					<td>{{ $product->title }}</td>
					<td><a href="/admin/category/{{ $product->productCategory->id }}">{{ $product->productCategory->name }}</a></td>
					<td>{{ $product->price }}<i class="la la-rub" aria-hidden="true" style="color: #5d78ff;"></i></td>
					<td>{{ $product->purchases }}</td>
					<td>
						@if($product->status == 1) <span class="kt-badge kt-badge--success kt-badge--inline kt-badge--pill">Да</span> @else <span class="kt-badge kt-badge--danger kt-badge--inline kt-badge--pill">Нет</span> @endif
					</td>
					<td><a href="/admin/product/{{ $product->id }}" class="btn btn-sm btn-clean btn-icon btn-icon-md" title="Редактировать"><i class="la la-edit"></i></a> @if($product->status == 1) <a href="/admin/product/status/{{ $product->id }}/0" class="btn btn-sm btn-clean btn-icon btn-icon-md" title="Скрывать товар"><i class="la la-eye-slash"></i></a> @elseif($product->status == 0) <a href="/admin/product/status/{{ $product->id }}/1" class="btn btn-sm btn-clean btn-icon btn-icon-md" title="Показывать товар"><i class="la la-eye"></i></a> @endif</td>
				</tr>
				@endforeach
				</tbody>
			</table>

			<!--end: Datatable -->
		</div>
	</div>
</div>
<div class="modal fade" id="new" tabindex="-1" role="dialog" aria-labelledby="newLabel" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Новый товар</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"></button>
            </div>
            <form class="kt-form-new" method="post" action="/admin/product/create">
				<div class="modal-body">
					<div class="form-group">
						<label for="title">Название:</label>
						<input type="text" class="form-control" placeholder="Название товара" name="title">
					</div>
					<div class="form-group">
						<label for="image">Ссылка на картинку:</label>
						<input type="text" class="form-control" placeholder="Ссылка на картинку" name="image">
					</div>
					<div class="form-group">
						<label for="description">Описание:</label>
						<textarea type="text" class="form-control" placeholder="Описание" name="description"></textarea>
					</div>
					<div class="form-group">
						<label for="price">Цена:</label>
						<textarea type="text" class="form-control" placeholder="Цена (только число: 15.00)" name="price"></textarea>
					</div>
					<div class="form-group">
						<label for="price">Ссылка на скачку:</label>
						<textarea type="text" class="form-control" placeholder="Ссылка на скачку" name="download_link"></textarea>
					</div>
					<div class="form-group">
						<label for="price">Пароль для скачки:</label>
						<textarea type="text" class="form-control" placeholder="Пароль для скачки" name="download_pass"></textarea>
					</div>
					<div class="form-group">
						<label for="name">Категория:</label>
						<select class="form-control" name="category_id">
							@foreach($categories as $category)
							<option value="{{ $category->id }}">{{ $category->name }}</option>
							@endforeach
						</select>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-dismiss="modal">Закрыть</button>
					<button type="submit" class="btn btn-primary">Добавить</button>
				</div>
            </form>
        </div>
    </div>
</div>
@endsection
