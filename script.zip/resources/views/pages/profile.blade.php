@extends('layout')

@section('content')
        <div class="header-title">
           <div class="wrapper">
                <span>Ваш профиль</span>
           </div>
        </div>
    </section>
    <section class="profile">
        <div class="profile-top-bar">
            <div class="wrapper flex flex-between flex-align-center flex-wrap">
                <div class="profile flex flex-between flex-align-center flex-wrap">
                    <div class="avatar">
                        <div class="image" style="background: url({{ Auth::user()->avatar }}) no-repeat center center; margin-top: -50px;"></div>
                    </div>
                    <div class="info">
                        <h4>{{ Auth::user()->username }}</h4>
                        <p>@if(Auth::user()->is_admin == 1) Администратор @else Пользователь @endif</p>
                        <p>Баланс: <b>{{ Auth::user()->balance }} <em>руб.</em></b></p>
                        <div class="form-group">
                          <form action="/promocode/activate" type="POST">
                          <input type="text" name="code" value="" placeholder="Введите промокод">
                          <button type="submit" name="button" aria-label="Активировать промокод">Активировать</button>
                        </div>
                    </div>
                </div>
                <div class="last-info">
                    <p>Последний вход с IP: <b>{{ Auth::user()->last_ip }}</b></p>
                    <a href="/logout" class="logout">Выйти</a>
                </div>
            </div>
        </div>
        <div class="profile-table">
            <div class="wrapper">
                <table>
                    <thead>
                        <tr>
                            <td>№ Заказа</td>
                            <td>Название</td>
                            <td>Цена</td>
                            <td>Категория</td>
                            <td>Куплен</td>
                            <td>Статус</td>
                            <td>Действие</td>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($purchases as $purchase)
                        <tr>
                            <td>{{ $purchase->id }}</td>
                            <td>{{ $purchase->product->title }} @if($purchase->product->download_pass) (Пароль: {{ $purchase->product->download_pass }}) @endif</td>
                            <td>{{ $purchase->price }} <i class="fa fa-rub" aria-hidden="true"></i></td>
                            <td>{{ $purchase->product->productCategory->name }}</td>
                            <td>{{ $purchase->created_at->toDatestring() }}</td>
                            <td>@if($purchase->status == 1) Заказ оплачен @elseif($purchase->status == 2) Заказ обработан @elseif($purchase->status == 3) Средства возвращены @endif</td>
                            <td><a href="@if($purchase->product->download_link) {{ $purchase->product->download_link }} @else {{ $settings->vk_support_link }} @endif" class="download">Скачать</a></td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </section>
@endsection
