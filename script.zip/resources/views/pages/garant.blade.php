@extends('layout')

@section('content')
        <div class="header-title">
           <div class="wrapper">
                <span>Наши гарантии</span>
           </div>
        </div>
    <section class="garant">
        <div class="wrapper">
            <div class="columns">
                <div class="col flex flex-around flex-wrap">
                    <div class="item-garant">
                        <div class="ico">
                            <div class="image feedback"></div>
                        </div>
                        <div class="info">
                            <h4>Отзывы наших покупателей</h4>
                            <p>Все отзывы на нашем сайте, были оставлены только реальными покупателями, не верите? Спросите у них сами! Нажав на Имя в отзыве, а также, система отзывов полностью открыта, где вы можете оставить как положительный, так и отрицательный отзыв о нашем магазине.</p>
                        </div>
                    </div>
                    <div class="item-garant">
                        <div class="ico">
                            <div class="image correct"></div>
                        </div>
                        <div class="info">
                            <h4>Проверенный товар</h4>
                            <p>Весь товар проходит тщательную проверку специалистами, мы не даем 100% гарантию, что после покупки скрипта, багов совсем не будет, учитывайте человеческий фактор.</p>
                        </div>
                    </div>
                </div>
                <div class="col flex flex-around flex-wrap">
                    <div class="item-garant">
                        <div class="ico">
                            <div class="image gift"></div>
                        </div>
                        <div class="info">
                            <h4>Быстрая доставка</h4>
                            <p>Сразу после покупки, в "Моих заказах" вы сможете скачать купленный товар.</p>
                        </div>
                    </div>
                    <div class="item-garant">
                        <div class="ico">
                            <div class="image customer-service"></div>
                        </div>
                        <div class="info">
                            <h4>Поддержка пользователей</h4>
                            <p>Наша поддержка, всегда готова ответить на любой ваш вопрос, а также проконсультировать вас перед покупкой</p>
                        </div>
                    </div>
                    <div class="item-garant">
                        <div class="ico">
                            <div class="image brain"></div>
                        </div>
                        <div class="info">
                            <h4>Умелые специалисты</h4>
                            <p>Наши специалисты приложат максимум усилий и времени, для решения всех возникающих проблем.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
