@extends('layout')

@section('content')
    <div class="header-title">
       <div class="wrapper">
            <span>Описание товара</span>
       </div>
    </div>
    <section class="news">
        <div class="news-items">
          <div class="item">
              <div class="wrapper flex flex-between">
                  <div class="new-image">
                      <!-- <img class="img" src="{{$product->image}}"> -->
                      <div class="bx-input script">

                      <div class="slider flex flex-between flex-align-center flex-wrap">
                           <div class="slider-image">
                               <div class="sliders">
                                   <a href="#" id="prev_2"></a>
                                   <div class="scroll" id="sliderAbout">
                                       <div class="slider-image" style="background: url({{ $product->image}})"></div>
                                       <div class="slider-image" style="background: url(https://webgamestore.ru/images/slider-image-1.png)"></div>
                                       <div class="slider-image" style="background: url(https://webgamestore.ru/images/dragonmoney.png)"></div>
                                   </div>
                                   <a href="#" id="next_2"></a>
                               </div>
                           </div>
                      </div>
                    </div>
                    <div class="buy-group">
                      <p class="product-price">Цена: <span @isset($newprice) style="text-decoration: line-through;" @endif>{{ $product->price }}</span> @isset($newprice) <span>{{ $newprice }}</span> @endif  р.</p>
                      @isset($newprice)<p>Вы активировали промокод на скидку для этого товара.</p>@endif
                                <a href="/product/{{ $product->id }}/buy" class="button-buy">Купить</a>
                                <a href="/product/{{ $product->id}}/addToBasket" class="add-to-cart purple-link">Добавить в корзину</a>
                    </div>
                  </div>
                  <div class="info">
                      <div class="heading product-heading-info">
                          <h4>{{ $product->title }}</h4>
                          <div class="product-description">
                            <textarea disabled style="height: 350px; resize: none;">{{ $product->description }}</textarea>
                          </div>
        <!-- <div class="dropdown">
                              <div class="heading">
                                  Доп.услуги
                              </div>
                              <div class="drop">
                                  <div class="item active flex flex-between flex-align-center">
                                     <div class="flex flex-align-center flex-between">
                                         <span></span> <p>Установка скрипта</p>
                                     </div>
                                     <b>200 руб.</b>
                                  </div>
                                  <div class="item  flex flex-between flex-align-center">
                                     <div class="flex flex-align-center flex-between">
                                         <span></span> <p>Установка скрипта</p>
                                     </div>
                                     <b>200 руб.</b>
                                  </div>
                                  <div class="item  flex flex-between flex-align-center">
                                     <div class="flex flex-align-center flex-between">
                                         <span></span> <p>Установка скрипта</p>
                                     </div>
                                     <b>200 руб.</b>
                                  </div>
                              </div>
                          </div> -->
                      </div>
                  </div>
              </div>
          </div>
        </div>
    </section>
@endsection
