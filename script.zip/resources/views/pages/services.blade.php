@extends('layout')

@section('content')
    <div class="header-title">
       <div class="wrapper">
            <span>Наши услуги</span>
       </div>
    </div>
    <section class="info">
        <div class="block scripts tabs">
            <div class="wrapper">
                <div class="title flex flex-center flex-align-center">
                    <h4>Все Услуги</h4>
                </div>
            </div>
            <div class="list-items">
               <div class="wrapper">
                @foreach($products as $product)
                <a href="/product/{{ $product->id }}" class="item">
                    <div class="bg" style="background: url({{ $product->image }}) no-repeat center center/ cover;"></div>
                    <div class="info">
                       <div class="top">
                            <div class="category">
                                <span>Категория:</span><b>{{ $product->productCategory->name }}</b>
                            </div>
                            <div class="descr">
                                <span>{{ $product->title }}</span>
                            </div>
                       </div>
                       <div class="price">
                           <span>{{ $product->price }}</span><b>РУБ</b>
                       </div>
                    </div>
                </a>
                @endforeach
               </div>
            </div>
        </div>
    </section>
@endsection
