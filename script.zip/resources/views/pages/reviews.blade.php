@extends('layout')

@section('content')
    <div class="header-title">
       <div class="wrapper">
            <span>Отзывы наших клиентов</span>
       </div>
    </div>
    <section class="reviews">
        <div class="reviews-items">
            @foreach($reviews as $item)
            <div class="review">
               <div class="wrapper">
                    <div class="top flex flex-between flex-align-center flex-wrap">
                        <div class="profile flex flex-start flex-align-center">
                            <div class="ava">
                                <div class="image" style="background: url({{ $item->reviewOwner->avatar }}) no-repeat 0 0;"></div>
                            </div>
                            <div class="username">
                                <span>{{ $item->reviewOwner->username }} </span><i class="fa fa-thumbs-@if($item->star == 1)up @elseif($item->star == 0)down @endif" aria-hidden="true" style="color: #a98bff;"></i>
                                @if(Auth::user())
                                @if($u->is_admin == 1)
                                @if($item->status == 1) <a href="/admin/review/status/{{ $item->id }}/2" class="btn btn-sm btn-clean btn-icon btn-icon-md" title="Скрывать отзыв"><i class="fa fa-eye-slash" style="color: #a98bff;"></i></a> @endif
                                @endif
                                @endif
                            </div>
                        </div>
                        <div class="date">
                            <span>{{ $item->created_at->todatestring() }}</span>
                        </div>
                    </div>
                    <div class="message">
                        <p>{{ $item->text }}</p>
                    </div>
               </div>
            </div>
            @endforeach
        </div>
        <div class="send-review-request">
           <div class="wrapper">
                <div class="title center flex flex-between flex-align-center">
                    <h4>Оставить отзыв</h4>
                </div>
                <div class="form-request">
                    <form action="/review/post" class="flex flex-between flex-wrap">
                        <div class="shribe-review">
                            <div class="bx-input">
                                <label>Написать отзыв</label>
                                <textarea name="review" id="review" maxlength="255" placeholder="Ваш отзыв..."></textarea>
                            </div>
                        </div>
                        <div class="sorting">
                            <div class="bx-input">
                                <label>Отзыв</label>
                                <select name="star" id="star" value="0">
                                    <option value="1">Положительный</option>
                                    <option value="0">Отрицательный</option>
                                </select>
                            </div>
                            <div class="bx-input">
                                <label>Привязать к скрипту</label>
                                <select name="script" id="script">
                                    @foreach($products as $product)
                                    <option value="{{ $product->id }}">{{ $product->title }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="bx-input">
                                <button type="submit">Опубликовать</button>
                            </div>
                        </div>
                    </form>
                </div>
           </div>
        </div>
    </section>
@endsection
