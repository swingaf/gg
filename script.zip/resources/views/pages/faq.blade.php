@extends('layout')

@section('content')
        <div class="header-title">
           <div class="wrapper">
                <span>Часто задаваемые вопросы</span>
           </div>
        </div>>
    <section class="faq">
        <div class="faq-items">
            @foreach($faq as $item)
            <div class="faq">
                <div class="wrapper">
                    <div class="heading">
                        <span>{{ $item->title }}</span>
                    </div>
                    <div class="more">
                        <p>{{ $item->text }}</p>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </section>
@endsection
