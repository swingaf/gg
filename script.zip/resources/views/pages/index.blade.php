@extends('layout')

@section('content')
    <section class="info">
        <div class="wrapper">
            <div class="block scripts">
                <div class="title flex flex-between flex-align-center">
                    <h4>Популярные скрипты</h4>
                    <a href="/catalog"><span>Смотреть все <i class="icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M424.4 214.7L72.4 6.6C43.8-10.3 0 6.1 0 47.9V464c0 37.5 40.7 60.1 72.4 41.3l352-208c31.4-18.5 31.5-64.1 0-82.6z"/></svg></i></span></a>
                </div>
                <div class="list-items">
                    <div class="scroll">
                          @foreach($top as $list)
                          <a href="/product/{{ $list->id }}" class="item">
                            <div class="bg" style="background: url({{ $list->image }}) no-repeat center center/ cover;"></div>
                            <div class="info">
                               <div class="top">
                                    <div class="category">
                                        <span>Категория:</span><b>{{ $list->productCategory->name }}</b>
                                    </div>
                                    <div class="descr">
                                        <span>{{ $list->title }}</span>
                                    </div>
                               </div>
                               <div class="price">
                                   <span>{{ $list->price }}</span><b>РУБ</b>
                               </div>
                            </div>
                        </a>
                        @endforeach
                    </div>
                </div>
            </div>
            <div class="block scripts last-buy">
                <div class="title flex flex-between flex-align-center">
                    <h4>Последние покупки</h4>
                </div>
                <div class="list-items">
                    <div class="scroll">
                      @foreach($purchases as $lastpurchase)
                      <a href="/product/{{ $lastpurchase->product->id }}" class="item">
                          <div class="bg" style="background: url({{ $lastpurchase->product->image }}) no-repeat center center/ cover;"></div>
                          <div class="info">
                             <div class="top">
                                  <div class="descr">
                                      <span>{{ $lastpurchase->product->title }}</span>
                                  </div>
                             </div>
                          </div>
                      </a>
                      @endforeach
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
