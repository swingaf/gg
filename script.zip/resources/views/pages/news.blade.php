@extends('layout')

@section('content')
    <div class="header-title">
       <div class="wrapper">
            <span>Наши новости</span>
       </div>
    </div>
    <section class="news">
        <div class="news-items">
          @foreach($news as $item)
          <div class="item">
              <div class="wrapper flex flex-between">
                  <div class="new-image">
                      <div class="img" style="background: url({{ $item->image }}) no-repeat center center;"></div>
                  </div>
                  <div class="info">
                      <div class="heading flex flex-between">
                          <h4>{{ $item->title }}</h4>
                          <div class="date">{{ \Carbon\Carbon::parse($item->created_at)->timezone('UTC')->diffForHumans() }}</div>
                      </div>
                      <div class="product-description">
                        <textarea disabled style="height: 263px; resize: none;">{{ $item->description }}</textarea>
                      </div>
                  </div>
              </div>
          </div>
          @endforeach
        </div>
    </section>
@endsection
