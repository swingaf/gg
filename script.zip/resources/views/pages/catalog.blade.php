@extends('layout')

@section('content')
<div class="header-title">
   <div class="wrapper">
        <span>Каталог скриптов</span>
   </div>
</div>

<section class="info">
    <div class="wrapper">
        <div class="block scripts">
            <div class="title flex flex-between flex-align-center">
                <h4>Популярные товары</h4>
            </div>
            <div class="list-items">
                <a href="#" id="prev"></a>
                <div class="scroll" id="slider_cat">
                    @foreach($top as $list)
                    <a href="/product/{{ $list->id }}" class="item">
                        <div class="bg" style="background: url({{ $list->image }}) no-repeat center center/ cover;"></div>
                        <div class="info">
                           <div class="top">
                                <div class="category">
                                    <span>Категория:</span><b>{{ $list->productCategory->name }}</b>
                                </div>
                                <div class="descr">
                                    <span>{{ $list->title }}</span>
                                </div>
                           </div>
                           <div class="price">
                               <span>{{ $list->price }}</span><b>РУБ</b>
                           </div>
                        </div>
                    </a>
                    @endforeach
                </div>
                <a href="#" id="next"></a>
            </div>
        </div>
    </div>
    <div class="block scripts tabs" style="margin-top: 90px;">
        <div class="wrapper">
            <div class="title flex flex-center flex-align-center">
                <h4>Все скрипты</h4>
            </div>
        </div>
        <div class="tabs-selector">
            <div class="wrapper">
                <ul>
                    <li class="{{ Request::is('catalog') ? 'active' : '' }}"><a href="/catalog">Все скрипты</a></li>
                    @foreach($categories as $category)
                    <li class="{{ Request::is('category/'.$category->id.'') ? 'active' : '' }}"><a href="/category/{{ $category->id }}">{{ $category->name }}</a></li>
                    @endforeach
                </ul>
            </div>
        </div>
        <div class="list-items">
           <div class="wrapper">
            @foreach($products as $item)
            <a href="/product/{{ $item->id }}" class="item">
                <div class="bg" style="background: url({{ $item->image }}) no-repeat center center/ cover;"></div>
                <div class="info">
                   <div class="top">
                        <div class="category">
                            <span>Категория:</span><b>{{ $item->productCategory->name }}</b>
                        </div>
                        <div class="descr">
                            <span>{{ $item->title }}</span>
                        </div>
                   </div>
                   <div class="price">
                       <span>{{ $item->price }}</span><b>РУБ</b>
                   </div>
                </div>
            </a>
            @endforeach
           </div>
        </div>
    </div>
    <div class="wrapper">
<div class="block scripts last-buy">
            <div class="title flex flex-between flex-align-center">
                <h4>Последние покупки</h4>
            </div>
            <div class="list-items">
                <div class="scroll">
                    @foreach($purchases as $lastpurchase)
                    <a href="/product/{{ $lastpurchase->product->id }}" class="item">
                        <div class="bg" style="background: url({{ $lastpurchase->product->image }}) no-repeat center center/ cover;"></div>
                        <div class="info">
                           <div class="top">
                                <div class="descr">
                                    <span>{{ $lastpurchase->product->title }}</span>
                                </div>
                           </div>
                        </div>
                    </a>
                    @endforeach
                </div>
            </div>
        </div>
    </div>
</section>




@endsection
